// ------------------------------------
// Assignment 2 Submission
// Name            : Aditya Kumar Bharti
// Roll Number     : 22CS30007
// link(pcap file) : https://drive.google.com/file/d/1dbAHagzPi79DUHCx-xN1LBOOkgtEWRU5/view?usp=drive_link
// ------------------------------------


#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>

#define PORT 5000
#define MAXLINE 1000

// Function to check if a string message starts with pattern
int startswith(char *message, char *pattern)
{
    int n = strlen(message);
    int m = strlen(pattern);

    if (m > n)
    {
        return 0;
    }

    for (int i = 0; i < m; i++)
    {
        if (message[i] != pattern[i])
            return 0;
    }
    return 1;
}

int main()
{
    // Declare variables
    char buffer[100];
    char *message = (char *)malloc(100); // Message to be sent to the server
    int sockfd, n;                       // File-Descriptor for the Client
    struct sockaddr_in servaddr;

    // Initializing the Server adddress
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);
    servaddr.sin_family = AF_INET;

    // Create the UDP Socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Fileptr
    FILE *fptr = NULL;

    // To track the word getting Transmitted
    int word_no = 0;

    // Done-Flag to exit
    int comp_flag = 1;

    while (comp_flag)
    {
        // Asks to user Which File-Name to be sent
        int fileno;
        if (word_no == 0)
        {
            printf("Enter the FileName No[1-3] wanna sent: ");
            scanf("%d", &fileno);

            // Create the string
            sprintf(message, "22CS30007_File%d.txt", fileno);
        }

        // Create the String
        if (word_no)
        {
            sprintf(message, "WORD%d", word_no);
        }

        // Send the Data-gram corresponding to the Message(Hello Server) to the Serever
        sendto(sockfd, message, strlen(message), 0, (struct sockaddr *)&servaddr, sizeof(servaddr));

        // Wati Until you recieve the response from the server
        int sizeofmesRec = recvfrom(sockfd, buffer, sizeof(buffer), 0, NULL, NULL);
        buffer[sizeofmesRec] = '\0';

        // If message Recieved starts with (NOTFOUND)
        int flag = startswith(buffer, strdup("NOTFOUND"));

        if (flag == 0)
        {
            // Check if the word is Hello
            int hello_flag = startswith(buffer, strdup("HELLO"));
            if (hello_flag)
            {
                // Create a File
                char new_file[100];
                sprintf(new_file, "Client_%s", message);
                fptr = fopen(new_file, "w");
                fprintf(fptr, "%s\n", buffer);

                // Increase word_no
                word_no++;
            }
            else
            {
                // Check if it is the Finish Message
                int finish_flag = startswith(buffer, strdup("FINISH"));
                if (finish_flag)
                {
                    // Write Finish and Close the File
                    fprintf(fptr, "%s\n", buffer);
                    fclose(fptr);

                    // print complete message
                    printf("File-Transefer for 22CS30007_file%d.txt completed\n", fileno);

                    // Reset word_no
                    word_no = 0;

                    // comp_flag
                    comp_flag = 0;
                }
                else
                {
                    // Write the word
                    fprintf(fptr, "%s\n", buffer);

                    // Increase word_no
                    word_no++;
                }
            }
        }
        else
        {
            printf("FILE NOT FOUND\n");
            comp_flag = 0;
        }
    }

    // Close the Socket
    close(sockfd);

    return 0;
}
