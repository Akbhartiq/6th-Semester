// ------------------------------------
// Assignment 2 Submission
// Name            : Aditya Kumar Bharti
// Roll Number     : 22CS30007
// link(pcap file) : https://drive.google.com/file/d/1dbAHagzPi79DUHCx-xN1LBOOkgtEWRU5/view?usp=drive_link
// ------------------------------------

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>

#define PORT 5000
#define MAXLEN 1000

// Function to check if a string message starts with pattern
int startswith(char *message, char *pattern)
{
    int n = strlen(message);
    int m = strlen(pattern);

    if (m > n)
    {
        return 0;
    }

    for (int i = 0; i < m; i++)
    {
        if (message[i] != pattern[i])
            return 0;
    }
    return 1;
}

int main()
{
    char buffer[100];
    char *message = (char *)malloc(200);
    int serverfd; // File Descriptor
    socklen_t len;
    struct sockaddr_in servaddr, cliaddr;

    // Create a UDP socket
    serverfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Configure Server Adddress
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Bind Server Address to the Socket
    bind(serverfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

    // File Pointer
    FILE *fptr = NULL;

    // Server-Running Message
    printf("Server is Running....\n");

    // Complete_flag
    int comp_flag = 1;

    while (comp_flag)
    {
        // Receive datagram from the client
        len = sizeof(cliaddr);
        int n = recvfrom(serverfd, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&cliaddr, &len);
        buffer[n] = '\0';

        // Checks if the message recieved starts with WORD
        int word_flag = startswith(buffer, strdup("WORD"));

        if (word_flag)
        {
            // Open the File in Read mode
            fscanf(fptr, "%s", message);

            int end_flag = startswith(message, "FINISH");
            if (end_flag)
            {
                printf("***File Transfer completed***\n");
                comp_flag = 0; // Reset it
            }
        }
        else
        {
            // Check if the File Exists
            fptr = fopen(buffer, "r");

            if (fptr == NULL)
            {
                sprintf(message, "NOTFOUND %s", buffer);
                comp_flag = 0; // reset it
            }
            else
            {
                fscanf(fptr, "%s", message);
            }
        }

        // Send a response to the client
        sendto(serverfd, message, strlen(message), 0,
               (struct sockaddr *)&cliaddr, len);
    }

    // Close the socket
    close(serverfd);

    return 0;
}
