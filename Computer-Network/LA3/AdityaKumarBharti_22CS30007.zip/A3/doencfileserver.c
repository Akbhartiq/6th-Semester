// =====================================
// Assignment 3 Submission
// Name: Aditya Kumar Bharti
// Roll number: 22CS30007
// Link of the pcap file: <https://drive.google.com/drive/folders/1JWIfS4jIV4DAJW2o_dPJ-IUSSLRuy3YD?usp=drive_link>
// =====================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* THE SERVER PROCESS */

int main(int argc, char *argv[])
{

    int sockfd, newsockfd; /* Socket descriptors */
    int clilen;
    struct sockaddr_in cli_addr, serv_addr;
    socklen_t cli_addr_len = sizeof(cli_addr);
    char client_ip[INET_ADDRSTRLEN];

    int i;

    char buffer[91]; /* We will use this buffer for communication */

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("Cannot create socket\n");
        exit(0);
    }

    // Feed the server Info...
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(argc > 1 ? atoi(argv[1]) : 20000);

    // Bind the server...(to the Socket)
    if (bind(sockfd, (struct sockaddr *)&serv_addr,
             sizeof(serv_addr)) < 0)
    {

        printf("Unable to bind local address\n");
        exit(0);
    }

    printf("Server is running on port %d.....\n", ntohs(serv_addr.sin_port));
    fflush(stdout);

    // Server starts Listenting at the Socket-Interface
    listen(sockfd, 5);

    while (1)
    {
        // Accept any Incoming Connection
        clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr,
                           &clilen);

        // Failure message
        if (newsockfd < 0)
        {
            printf("Accept error\n");
            exit(0);
        }

        if (fork() == 0)
        {

            close(sockfd); /* Close the old socket since all communications will be through
                               the new socket.*/
            // Get the Port of the Client
            if (getpeername(newsockfd, (struct sockaddr *)&cli_addr, &cli_addr_len) == -1)
            {
                perror("Get Peer Name Failed\n");
                close(newsockfd);
                exit(0);
            }

            // Convert the Ip to string
            inet_ntop(AF_INET, &cli_addr.sin_addr, client_ip, sizeof(client_ip));

            // Print the Connection Message
            printf("Client connected from IP:%s , Port:%d \n", client_ip, ntohs(cli_addr.sin_port));
            while (1)
            {
                // child Processs(will do multiple file Encryption if possible so while(1))

                // Get the Key
                char key[28];
                int curr = 0; // Pointer to fill the key

                while (1)
                {
                    // Mem-set
                    memset(buffer, '\0', 28);

                    // Recieve-From(This will not wait to get all the 26Bits so while(1) and marker $ for End)
                    recv(newsockfd, buffer, 28, 0);

                    // Lenght of Message
                    int len = strlen(buffer);

                    // Recieve the Entire Message
                    if (buffer[len - 1] == '$')
                    {
                        for (int idx = 0; idx < len - 1; idx++)
                        {
                            key[curr++] = buffer[idx];
                        }
                        break;
                    }
                    else
                    {
                        // More key-mapping still to be recieved
                        for (int idx = 0; idx < len; idx++)
                        {
                            key[curr++] = buffer[idx];
                        }
                    }
                }

                // Convert all the Key to Upper-Case(For uniformity)
                for (int i = 0; i < 26; i++)
                {
                    if (key[i] >= 'a' && key[i] <= 'z')
                    {
                        key[i] = key[i] - 'a' + 'A';
                    }
                    else
                    {
                        // Do Nothing : Be happy
                    }
                }

                // Create the File-Name(to store the text)
                char fileName[30];
                sprintf(fileName, "%s.%d.txt", client_ip, ntohs(cli_addr.sin_port));

                // Create the File
                FILE *fptr;
                fptr = fopen(fileName, "w");
                if (fptr == NULL)
                {
                    printf("Unable to open the File\n");
                    exit(0);
                }

                // Keep Receiving Untill you see the EOF
                while (1)
                {
                    memset(buffer, '\0', 91);
                    recv(newsockfd, buffer, 91, 0); // It should be 90 only as the client TCP socket can send the 91B together and then strlen function might not work as expected

                    // Check for EOF character
                    int len = strlen(buffer);

                    if (buffer[len - 1] == EOF)
                    {
                        buffer[len - 1] = '\0';
                        fprintf(fptr, "%s", buffer);
                        break;
                    }

                    fprintf(fptr, "%s", buffer);
                }

                // Close the File and Open in Read-Mode
                fclose(fptr);
                fptr = fopen(fileName, "r");

                // Create the Encrypted File
                char encFileName[40];
                sprintf(encFileName, "%s.enc", fileName);
                FILE *enfptr;
                enfptr = fopen(encFileName, "w");

                // Character to read the text from plain-Text file
                char ch;

                while ((ch = fgetc(fptr)) != EOF)
                {
                    // If lower-case map it and convert it to lower case again(as key are for upper case)
                    if (ch >= 'a' && ch <= 'z')
                    {
                        ch = key[ch - 'a'] - 'A' + 'a';
                    }
                    else if (ch >= 'A' && ch <= 'Z')
                    {
                        ch = key[ch - 'A'];
                    }
                    else
                    {
                        // Do-Nothing Be Happy
                    }
                    fputc(ch, enfptr);
                    fflush(enfptr);
                }

                // Send the  Encrypted file
                enfptr = fopen(encFileName, "r");

                while (1)
                {
                    memset(buffer, '\0', 91);
                    for (int i = 0; i < 90; i++)
                    {
                        ch = fgetc(enfptr);
                        buffer[i] = ch;
                        if (ch == EOF)
                            break;
                    }
                    send(newsockfd, buffer, strlen(buffer) + 1, 0);
                    if (ch == EOF)
                        break;
                }

                // May be Server Need to do more Encryption
            }
            close(newsockfd);
        }

        close(newsockfd);
    }

    return 0;
}
