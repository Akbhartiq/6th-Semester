// =====================================
// Assignment 3 Submission
// Name: Aditya Kumar Bharti
// Roll number: 22CS30007
// Link of the pcap file: <https://drive.google.com/drive/folders/1JWIfS4jIV4DAJW2o_dPJ-IUSSLRuy3YD?usp=drive_link>
// =====================================

/*    THE CLIENT PROCESS */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{

    int sockfd; // File Descriptor for the Socket

    // server address
    struct sockaddr_in serv_addr;

    // Integer i (Used later for reading file)
    int i;

    /* Opening a socket is exactly similar to the server process */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Unable to create socket\n");
        exit(0);
    }

    // Feed the info.. of the server to connect
    serv_addr.sin_family = AF_INET;                               // IP4
    inet_aton("127.0.0.1", &serv_addr.sin_addr);                  // IP adddress of the Server
    serv_addr.sin_port = htons(argc > 1 ? atoi(argv[1]) : 20000); // Port: 20000

    // Trying to connect(By this time server must be listening.. then only this will work)
    if ((connect(sockfd, (struct sockaddr *)&serv_addr,
                 sizeof(serv_addr))) < 0)
    {

        perror("Unable to connect to server\n");
        exit(0);
    }

    // Connection Betweent the Server and the Client is Established
    char filename[100];
    FILE *fptr;

    int flag = 1; // Flag to Exit from the Outer-Loop(No more Encryption)
    do
    {
        printf("\n+--------------------------Encryption%d--------------------------+\n", flag++);
        while (1)
        {
            printf("Enter the name of the file: ");
            fflush(stdout);
            scanf("%[^\n]", filename);

            // Check if the File exists
            fptr = fopen(filename, "r");
            if (fptr == NULL)
            {
                // To clear the stdin
                getchar();
                printf("NOTFOUND %s\n", filename);
            }
            else
            {
                break;
            }
        }

        // Clear the stdin
        getchar();

        // File is there...
        char key[28];
        while (1)
        {
            printf("Enter the key: ");
            fflush(stdout);
            scanf("%26[^\n]", key);

            if (strlen(key) < 26)
            {
                getchar();
                printf("Invalid Key\n");
            }
            else
            {
                key[26] = '$'; // End-Marker for the Key
                key[27] = '\0';
                break;
            }
        }

        // send the Key
        send(sockfd, key, strlen(key) + 1, 0);

        // Clear the stdin
        getchar();

        // Send the content of the  File
        char buffer[91];
        while (1)
        {
            // Init buffer with zero
            memset(buffer, '\0', 91);

            // Reset i to zero
            i = 0;
            char ch;

            // Read the file
            while (i < 90)
            {
                ch = fgetc(fptr);
                buffer[i] = ch;
                if (ch == EOF)
                    break;
                i++;
            }

            // Send the Packets
            send(sockfd, buffer, strlen(buffer) + 1, 0);
            if (ch == EOF)
                break;
        }

        // Start-Receiving the Encrypted Files
        char enFile[110];
        sprintf(enFile, "%s.enc", filename);

        FILE *enfptr;
        enfptr = fopen(enFile, "w");

        while (1)
        {
            memset(buffer, '\0', 91);
            recv(sockfd, buffer, 91, 0);

            // Check if the EOF has been Recieved or Not
            int len = strlen(buffer);
            if (buffer[len - 1] == EOF)
            {

                buffer[len - 1] = '\0';
                fprintf(enfptr, "%s", buffer);
                fflush(enfptr);
                break;
            }

            fprintf(enfptr, "%s", buffer);
        }

        // Print the filenames
        printf("+---------------------------------------------------------------+\n");
        printf("File is Encrypted : Orig.(%s)\tEnc.(%s)\n", filename, enFile);
        printf("+---------------------------------------------------------------+\n");

        printf("Do you want to Encrypt more file : ");
        fflush(stdout);

        char resp[10];
        scanf("%s", resp);
        if (!strcmp(resp, "n") || !strcmp(resp, "no") || !strcmp(resp, "N") || !strcmp(resp, "No") || !strcmp(resp, "NO") || !strcmp(resp, "nO"))
        {
            flag = 0;
        }
        // Clear the stdin
        getchar();

    } while (flag);

    close(sockfd);

    return 0;
}
