#include "ksocket.h"

// Global Variables
int sm_mutex;
int bind_mutex;
_ktpSocket *SM;
struct sembuf pop, vop;

int global = 0;
int boolval = 0;

// Signal Handler
void signal_handler(int signum)
{
    // Detach from the shared Memory
    shmdt(SM);
    // Delete the Mutex
    semctl(sm_mutex, 0, IPC_RMID);
    // Exit the program
    exit(0);
}

// DropMessage Simulation
int dropMessage()
{
    // Drop with probability p
    return (rand() % 100) < (p * 100);
}

// Thread R
void *ThreadR()
{
    printf("ThreadR started\n");
    // Declare read sets
    fd_set readfds;
    int max_sd;

    // Enter the infinite loop
    while (1)
    {
        global++;

        // Initialize the readfds
        FD_ZERO(&readfds);
        max_sd = 0;

        // Wait on mutex
        P(sm_mutex);

        // Add all the active ktpSockets to the readfds
        for (int i = 1; i <= N; i++)
        {
            if (SM[i].is_active == 1)
            {
                FD_SET(SM[i].upd_socket_id, &readfds);
                if (SM[i].upd_socket_id > max_sd)
                {
                    max_sd = SM[i].upd_socket_id;
                }
            }
        }

        // Release the mutex
        V(sm_mutex);

        // Timout Struct
        struct timeval tv;
        tv.tv_sec = T;
        tv.tv_usec = 0;

        // Select on the readfds
        int retval = select(max_sd + 1, &readfds, NULL, NULL, &tv);

        if (retval == -1)
        {
            /*Error has occurred*/

            perror("ThreadR : select");

            kill(getpid(), SIGINT);
        }

        // int numberofAckedSend = 0;

        if (retval == 0)
        {

            int val = -1;
            // printf("Enter the val : ");
            // scanf("%d", &val);
            if (val == 1)
            {
                // Print the status of 2 KtpSockts
                printf("Ktpsocket-1\n");
                printf("is_active : %d\n", SM[1].is_active);
                printf("Sender Buffer Size : %d\n", SM[1].sendingBuffer.send_buffer_sz);
                printf("Sending Buffer Left-ptr : %d\n", SM[1].sendingBuffer.left);
                printf("Sending Buffer Right-ptr : %d\n", SM[1].sendingBuffer.right);
                printf("Number of Message in the buffer : %d\n", SM[1].sendingBuffer.size);
                for (int i = 1; i <= SEND_BUF_SIZE; i++)
                {
                    printf("%d", SM[1].sendingBuffer.lengthOfMessageSent[i]);
                }
                printf("Sending window size : %d\n", SM[1].sendingWindow.size);
                printf("Send_base : %d\n", SM[1].sendingWindow.send_base);
                printf("Next_seq : %d\n", SM[1].sendingWindow.next_seq);
                printf("Ktpsocket-2\n");
                printf("is_active : %d\n", SM[2].is_active);
                printf("Receiving Buffer Size : %d\n", SM[2].ReceivingBuffer.recv_buff_size);
                printf("Receiving Buffer recv_ptr : %d\n", SM[2].ReceivingBuffer.recv_pointer);
                printf("Receiving Buffer write-ptr : %d\n", SM[2].ReceivingBuffer.write_pointer);
                for (int i = 1; i <= RECV_BUF_SIZE; i++)
                {
                    printf("%d", SM[2].ReceivingBuffer.recv_buffer_valid[i]);
                }
                for (int i = 1; i <= RECV_BUF_SIZE; i++)
                {
                    printf("%d", SM[2].ReceivingBuffer.lengthOfMessageRecv[i]);
                }
                printf("Nospace : %d \n", SM[2].ReceivingBuffer.nospace);
                printf("recv_start : %d\n", SM[2].ReceivingWindow.recv_start);
                printf("recv_end : %d\n", SM[2].ReceivingWindow.recv_end);
                printf("size : %d\n", SM[2].ReceivingWindow.size);
                printf("last_acked : %d\n", SM[2].ReceivingWindow.last_acked);

                // Re-ask val
                scanf("%d", &val);
            }

            P(sm_mutex);

            /*For all of the active ktpSockets check if no-space was initially one and now is zero*/
            for (int i = 1; i <= N; i++)
            {
                if (SM[i].is_active == 1)
                {

                    if (SM[i].ReceivingBuffer.nospace == 0 || SM[i].ReceivingBuffer.recv_buff_size < RECV_BUF_SIZE)
                    {
                        SM[i].ReceivingBuffer.nospace = 0;

                        // Send Dup-ack for the last acked packet
                        if (SM[i].ReceivingWindow.last_acked == -1)
                            continue;
                        _packet pckt;
                        pckt.is_data = htonl(0);
                        pckt.seq_no = htonl(SM[i].ReceivingWindow.last_acked);
                        pckt.updated_recv_window_size = htonl(RECV_BUF_SIZE - SM[i].ReceivingBuffer.recv_buff_size);
                        // Update recv_window_size
                        SM[i].ReceivingWindow.size = RECV_BUF_SIZE - SM[i].ReceivingBuffer.recv_buff_size;
                        // Update recv_start and recv_end
                        SM[i].ReceivingWindow.recv_start = SM[i].ReceivingWindow.last_acked + 1;
                        if (SM[i].ReceivingWindow.recv_start > NUM_SEQ)
                        {
                            SM[i].ReceivingWindow.recv_start = 1;
                        }
                        // Update the Recv_End
                        int val = RECV_BUF_SIZE - SM[i].ReceivingBuffer.recv_buff_size;
                        // SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1;
                        if (SM[i].ReceivingWindow.recv_start + val - 1 > NUM_SEQ)
                        {
                            SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1 - NUM_SEQ;
                        }
                        else
                        {
                            SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1;
                        }

                        printf("Thread R : sending the Ack_no = %d by i = %d \n", SM[i].ReceivingWindow.last_acked, i);
                        sendto(SM[i].upd_socket_id, &pckt, sizeof(_packet), 0, (struct sockaddr *)(&SM[i].dest_addr), sizeof(SM[i].dest_addr));
                    }
                }
            }
            V(sm_mutex);
        }
        if (retval > 0)
        {
            /*Retval is the Number of Ready readfds*/

            // Wait on Mutex
            P(sm_mutex);

            /*check for all the filtered readfds*/
            for (int i = 1; i <= N; i++)
            {
                if (SM[i].is_active == 1)
                {
                    // Check if it is set in readfds
                    if (FD_ISSET(SM[i].upd_socket_id, &readfds))
                    {
                        // Get the Destination IP/PORT
                        struct sockaddr dest;
                        socklen_t destLen = sizeof(dest);

                        // Make a recv call to get the _packet
                        _packet pckt;

                        // Get the Packets
                        int lenRecv = recvfrom(SM[i].upd_socket_id, &pckt, sizeof(_packet), 0, &dest, &destLen);

                        if (lenRecv < 0)
                        {

                            perror("initksocket : recvfrom() failed");

                            V(sm_mutex);
                            kill(getpid(), SIGINT);

                            // It will eventually Exit the program
                        }

                        // See if you want to Drop it... using DropMessage()
                        // if (dropMessage())
                        // {
                        //     // Print packet info in separet line
                        //     // printf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
                        //     // printf("For i = %d : ", i);
                        //     // printf("is_data = %d seq_no = %d\n", ntohl(pckt.is_data), ntohl(pckt.seq_no));
                        //     // printf("updated_recv_window_size = %d\n", ntohl(pckt.updated_recv_window_size));
                        //     // printf("updated_send_window_size = %d\n", (pckt.updated_recv_window_size));
                        //     // printf("%s\n", pckt.data);
                        //     // printf("ThreadR : Dropped Packet\n");
                        //     // printf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
                        //     printf("ThreadR : Received but DROPPED pkt , seq_no = %d by i = %d \n", ntohl(pckt.seq_no), i);

                        //     continue;
                        // }

                        printf("ThreadR : Received pkt , seq_no = %d by i = %d \n", ntohl(pckt.seq_no), i);

                        // Get the seq_no
                        int seq_no = ntohl(pckt.seq_no);

                        // Dont'care about this...
                        if (seq_no < 0)
                            continue;

                        // Check the type of the Packets
                        if (ntohl(pckt.is_data) == 1)
                        {
                            /*Data Packet*/

                            printf("ThreadR : SM[%d].ReceivingWindow.last_acked : %d\n", i, SM[i].ReceivingWindow.last_acked);
                            printf("ThreadR : Recv_start : %d\n", SM[i].ReceivingWindow.recv_start);
                            if (SM[i].ReceivingWindow.last_acked == seq_no || (SM[i].ReceivingWindow.recv_start > 10 && seq_no >= 1 && seq_no < SM[i].ReceivingWindow.recv_start) || (seq_no < SM[i].ReceivingWindow.recv_start || seq_no >= (NUM_SEQ - (10 - SM[i].ReceivingWindow.recv_start))))
                            {
                                /*Still Send the Acknowledgement for the alst Acked*/
                                /*Already acked*/
                                _packet ack;
                                ack.is_data = htonl(0);
                                ack.seq_no = htonl(seq_no);
                                ack.updated_recv_window_size = htonl(SM[i].ReceivingWindow.size);

                                // Send this Packet...
                                int retVal = sendto(SM[i].upd_socket_id, &ack, sizeof(_packet), 0, (struct sockaddr *)&SM[i].dest_addr, (socklen_t)sizeof(SM[i].dest_addr));
                                if (retVal < 0)
                                {
                                    perror("Thread R : sendto failed\n");
                                    kill(getpid(), SIGINT);
                                }
                                printf("Thread R: Last-ack2 >> send the ack seq_no = %d , by i = %d\n", seq_no, i);
                                continue;
                            }

                            int flag = FALSE;

                            // Check if the packet is in the receving window
                            if (SM[i].ReceivingWindow.size == SM[i].ReceivingWindow.recv_end - SM[i].ReceivingWindow.recv_start + 1)
                            {
                                /*Case 1 : No wrap in Queue*/
                                if (seq_no <= SM[i].ReceivingWindow.recv_end && seq_no >= SM[i].ReceivingWindow.recv_start)
                                {
                                    // set flag to TRUE
                                    flag = TRUE;
                                }
                            }
                            else
                            {
                                /*Case 2:  Wrap in Queue*/
                                if (seq_no <= SM[i].ReceivingWindow.recv_end || seq_no >= SM[i].ReceivingWindow.recv_start)
                                {
                                    // set  flag to TRUE
                                    flag = TRUE;
                                }
                            }

                            if (flag == FALSE)
                                continue;

                            // numberofAckedSend++;

                            // First sequence Number that I was Expecting...
                            // Where should i write it in the Receiving Buffer
                            int wrt_ptr_idx = seq_no % RECV_BUF_SIZE;
                            if (wrt_ptr_idx == 0)
                                wrt_ptr_idx = RECV_BUF_SIZE;

                            // Store in the Receiving Buffer

                            memcpy(SM[i].ReceivingBuffer.recv_buffer[wrt_ptr_idx], pckt.data, MESSAGE_SIZE);

                            // Update the Receiving Window
                            SM[i].ReceivingWindow.wndw[seq_no] = wrt_ptr_idx;

                            // Update the Receving Buffer

                            SM[i].ReceivingBuffer.recv_buffer_valid[wrt_ptr_idx] = seq_no;
                            SM[i].ReceivingBuffer.lengthOfMessageRecv[wrt_ptr_idx] = MESSAGE_SIZE;
                            SM[i].ReceivingBuffer.recv_buff_size++;
                            if (SM[i].ReceivingBuffer.recv_buff_size == RECV_BUF_SIZE)
                            {
                                SM[i].ReceivingBuffer.nospace = 1;
                            }

                            // Send the ACK

                            int j = SM[i].ReceivingWindow.recv_start;

                            int count = 0;
                            while (SM[i].ReceivingWindow.wndw[j] != -1)
                            {

                                SM[i].ReceivingWindow.wndw[j] = -1;
                                j++;
                                count++;
                                // Will be acked
                                if (j > NUM_SEQ)
                                {
                                    j = 1;
                                }
                            }
                            if (j != SM[i].ReceivingWindow.recv_start)
                            {
                                // send the ack for j-1

                                _packet ack;
                                ack.is_data = htonl(0);
                                ack.seq_no = htonl((j - 1) ? (j - 1) : NUM_SEQ);
                                ack.updated_recv_window_size = htonl(RECV_BUF_SIZE - SM[i].ReceivingBuffer.recv_buff_size);

                                printf("Thread R: send the ack seq_no = %d , by i = %d\n", (j - 1) ? (j - 1) : NUM_SEQ, i);
                                sendto(SM[i].upd_socket_id, &ack, sizeof(_packet), 0, (struct sockaddr *)&SM[i].dest_addr, sizeof(SM[i].dest_addr));

                                // Update the Receiving wndw
                                SM[i].ReceivingWindow.last_acked = (j - 1) ? (j - 1) : NUM_SEQ;

                                SM[i].ReceivingWindow.recv_start = j;
                                if (SM[i].ReceivingWindow.recv_start == NUM_SEQ + 1)
                                {
                                    SM[i].ReceivingWindow.recv_start = 1;
                                }
                                SM[i].ReceivingWindow.size -= count;
                                // Update the Recv_End
                                int val = RECV_BUF_SIZE - SM[i].ReceivingBuffer.recv_buff_size;
                                SM[i].ReceivingWindow.size = val;
                                // SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1;
                                if (SM[i].ReceivingWindow.recv_start + val - 1 > NUM_SEQ)
                                {
                                    SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1 - NUM_SEQ;
                                }
                                else
                                {
                                    SM[i].ReceivingWindow.recv_end = SM[i].ReceivingWindow.recv_start + val - 1;
                                }
                            }
                        }
                        else
                        {

                            /*Acknowledgement Packet*/
                            int last_acked = SM[i].sendingWindow.send_base - 1;

                            if (last_acked == 0)
                            {
                                last_acked = NUM_SEQ;
                            }
                            if (seq_no == last_acked)
                            {
                                /*Already acked*/
                                int updt_size = ntohl(pckt.updated_recv_window_size);
                                SM[i].sendingBuffer.send_buffer_sz = updt_size;
                                continue;
                            }

                            /*If next_seq == send_base*/
                            if (SM[i].sendingWindow.next_seq == SM[i].sendingWindow.send_base)
                            {
                                /*Just Update the Sending Winow-size*/
                                continue;
                            }

                            // Check Acknowledgement should be in proper Range
                            int flag = FALSE;

                            printf("ThreadR: SM[%d].sendingWindow.next_Seq : %d\n", i, SM[i].sendingWindow.next_seq);
                            printf("ThreadR: SM[%d].sendingWindow.send_base : %d\n", i, SM[i].sendingWindow.send_base);
                            if (SM[i].sendingWindow.next_seq > SM[i].sendingWindow.send_base)
                            {
                                if (seq_no < SM[i].sendingWindow.next_seq && seq_no >= SM[i].sendingWindow.send_base)
                                {
                                    flag = TRUE;
                                }
                            }
                            else
                            {
                                if (seq_no < SM[i].sendingWindow.next_seq || seq_no >= SM[i].sendingWindow.send_base)
                                {
                                    flag = TRUE;
                                }
                            }

                            if (flag == FALSE)
                                continue;

                            // Update the Sending Window
                            int start = SM[i].sendingWindow.send_base; // 121
                            int end = (seq_no + 1) <= NUM_SEQ ? (seq_no + 1) : 1;
                            int count = 0;

                            while (start != end)
                            {
                                SM[i].sendingBuffer.lengthOfMessageSent[SM[i].sendingBuffer.left] = -1;
                                SM[i].sendingBuffer.size--;
                                SM[i].sendingBuffer.left++;
                                if (SM[i].sendingBuffer.left == SEND_BUF_SIZE + 1)
                                {
                                    SM[i].sendingBuffer.left = 1;
                                }
                                count++;
                                SM[i].sendingWindow.wndw[start] = -1;
                                SM[i].sendingWindow.lastSendTime[start] = -1;
                                SM[i].sendingWindow.size--;
                                start++;
                                if (start > NUM_SEQ)
                                {
                                    start = 1;
                                }
                            }
                            SM[i].sendingWindow.send_base = start;
                            SM[i].sendingBuffer.send_buffer_sz = ntohl(pckt.updated_recv_window_size);

                            // Possible next_seq
                            int pos_next_Seq = SM[i].sendingBuffer.send_buffer_sz + SM[i].sendingWindow.send_base;
                            if (pos_next_Seq > NUM_SEQ)
                            {
                                pos_next_Seq = pos_next_Seq - NUM_SEQ;
                            }

                            if (SM[i].sendingWindow.send_base <= SM[i].sendingWindow.next_seq)
                            {

                                if (SM[i].sendingWindow.next_seq > pos_next_Seq)
                                {

                                    // Mark other window as -1
                                    int j = pos_next_Seq;

                                    while (j != SM[i].sendingWindow.next_seq)
                                    {
                                        // Possible src of error
                                        // printf("stuck1\n");
                                        SM[i].sendingBuffer.lengthOfMessageSent[SM[i].sendingWindow.wndw[j]] = -1;
                                        SM[i].sendingWindow.wndw[j] = -1;
                                        SM[i].sendingWindow.lastSendTime[j] = -1;
                                        SM[i].sendingWindow.size--;
                                        j++;
                                        if (j > NUM_SEQ)
                                        {
                                            j = 1;
                                        }
                                    }
                                    SM[i].sendingWindow.next_seq = pos_next_Seq;
                                }
                            }
                            else
                            {
                                if (SM[i].sendingWindow.next_seq > pos_next_Seq || SM[i].sendingWindow.send_base < pos_next_Seq)
                                {
                                    // Mark other window as -1
                                    int j = pos_next_Seq;
                                    while (j != SM[i].sendingWindow.next_seq)
                                    {

                                        // Possible src of error
                                        SM[i].sendingBuffer.lengthOfMessageSent[SM[i].sendingWindow.wndw[j]] = -1;
                                        SM[i].sendingWindow.wndw[j] = -1;
                                        SM[i].sendingWindow.lastSendTime[j] = -1;
                                        SM[i].sendingWindow.size--;
                                        j++;
                                        if (j > NUM_SEQ)
                                        {
                                            j = 1;
                                        }
                                    }
                                    SM[i].sendingWindow.next_seq = pos_next_Seq;
                                }
                            }
                        }
                    }
                }
            }

            V(sm_mutex);
        }
    }
}

// Thread S
void *ThreadS()
{
    printf("Sender started\n");
    while (1)
    {

        sleep(T / 2);

        // Wait on sem_mutex
        P(sm_mutex);
        // For any of the active ktpSocket check if timeout has occured
        for (int i = 1; i <= N; i++)
        {
            if (SM[i].is_active == 1)
            {

                // Check if the sending window is not empty
                if (SM[i].sendingWindow.size > 0)
                {
                    // Check if the first message has timed out
                    printf("ThreadS : TimoutEvent\n");
                    if (SM[i].sendingWindow.lastSendTime[SM[i].sendingWindow.send_base] != -1 &&
                        time(NULL) - SM[i].sendingWindow.lastSendTime[SM[i].sendingWindow.send_base] >= T)
                    {
                        // Resend the Entire Message within the sending window
                        int j = SM[i].sendingWindow.send_base;
                        while (j != SM[i].sendingWindow.next_seq)
                        {
                            // Send the Message with Sequence Number and Update the lastTime
                            _packet pckt;
                            pckt.is_data = htonl(1);
                            pckt.seq_no = htonl(j);

                            strcpy(pckt.data, SM[i].sendingBuffer.send_buffer[SM[i].sendingWindow.wndw[j]]);

                            printf("ThreadS : Sending seq_no = %d by i = %d\n", j, i);
                            sendto(SM[i].upd_socket_id, &pckt, sizeof(_packet), 0, (struct sockaddr *)&SM[i].dest_addr, sizeof(SM[i].dest_addr));

                            SM[i].sendingWindow.lastSendTime[j] = time(NULL);
                            j = j + 1;
                            if (j == NUM_SEQ + 1)
                            {
                                j = 1;
                            }
                        }
                    }
                }
            }
        }

        // For all of the active ktpSocket check if any message has to be sent
        for (int i = 1; i <= N; i++)
        {

            if (SM[i].is_active == 1)
            {
                /*Socket is Active*/
                // Get the sending Window size
                int swnd_size = SM[i].sendingBuffer.send_buffer_sz;
                int counter = 0; // To track if the sending window is full

                // Iterate over the sending buffer
                if (SM[i].sendingBuffer.size > 0)
                {

                    int j = SM[i].sendingBuffer.left;
                    int entryFlag = TRUE;

                    while (entryFlag == TRUE || j != SM[i].sendingBuffer.right)
                    {
                        entryFlag = FALSE;

                        // Check if we are still under sending window
                        if (counter == swnd_size)
                        {
                            break;
                        }

                        // Check if the message has not been sent
                        if (SM[i].sendingBuffer.lengthOfMessageSent[j] == -1)
                        {
                            // This Message has not been sent
                            // Send the Message with Sequence Number and Update the lastTime

                            _packet pckt;
                            pckt.is_data = htonl(1);
                            pckt.seq_no = htonl(SM[i].sendingWindow.next_seq);

                            strcpy(pckt.data, SM[i].sendingBuffer.send_buffer[j]);

                            printf("ThreadS : Sending seq_no = %d by i = %d\n", SM[i].sendingWindow.next_seq, i);
                            int lenSend = sendto(SM[i].upd_socket_id, &pckt, sizeof(_packet), 0, (struct sockaddr *)&SM[i].dest_addr, sizeof(SM[i].dest_addr));
                            if (lenSend < 0)
                            {
                                perror("ThreadS : sendto failed");
                                kill(getpid(), SIGINT);
                            }

                            SM[i].sendingWindow.lastSendTime[SM[i].sendingWindow.next_seq] = time(NULL);
                            SM[i].sendingWindow.wndw[SM[i].sendingWindow.next_seq] = j;
                            SM[i].sendingBuffer.lengthOfMessageSent[j] = MESSAGE_SIZE;
                            SM[i].sendingWindow.size = SM[i].sendingWindow.size + 1;
                            SM[i].sendingWindow.next_seq = SM[i].sendingWindow.next_seq + 1;
                            if (SM[i].sendingWindow.next_seq == NUM_SEQ + 1)
                            {
                                SM[i].sendingWindow.next_seq = 1;
                            }
                        }
                        // Track already sent Message also
                        counter = counter + 1;

                        // Incrment the right pointer
                        j = j + 1;
                        if (j == SEND_BUF_SIZE + 1)
                        {
                            j = 1;
                        }
                    }
                }
            }
        }

        // Release the Mutex
        V(sm_mutex);
    }
}

int main()
{
    // Seed the Time
    srand(time(NULL));

    // Register the signal handler
    signal(SIGINT, signal_handler);

    // Create Mutex for the shared Memory
    int sm_mutex_key = ftok("/", 'A');
    if (sm_mutex_key == -1)
    {
        perror("initksocket : ftok");
        exit(1);
    }
    sm_mutex = semget(sm_mutex_key, 1, IPC_CREAT | 0666);
    if (sm_mutex == -1)
    {
        perror("initksocket : semget");
        exit(1);
    }
    // Initialize the Mutex(with value 1)
    semctl(sm_mutex, 0, SETVAL, 1);

    // Bind Mutex for the Shared Memory
    int bind_mutex_key = ftok("/", 'B');
    if (bind_mutex_key == -1)
    {
        perror("initksocket : ftok");
        exit(1);
    }
    bind_mutex = semget(bind_mutex_key, 1, IPC_CREAT | 0666);
    if (bind_mutex == -1)
    {
        perror("initksocket : semget");
        exit(1);
    }
    semctl(bind_mutex, 0, SETVAL, 0);

    // Initialize the pop,vop
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    // Create the shared Memory
    int sm_key = ftok("/", 'C');
    if (sm_key == -1)
    {
        perror("initksocket : ftok");
        exit(1);
    }
    int sm_id = shmget(sm_key, (N + 1) * sizeof(_ktpSocket), IPC_CREAT | 0666);
    if (sm_id == -1)
    {
        perror("initksocket : shmget");
        exit(1);
    }

    // Attach to the shared Memory
    SM = (_ktpSocket *)shmat(sm_id, NULL, 0);
    if (SM == (_ktpSocket *)-1)
    {
        perror("initksocket : shmat");
        exit(1);
    }

    // Create N number of ktpSockets and Initialize them
    for (int i = 1; i <= N; i++)
    {
        SM[i].is_active = 0;                                  // Free to use
        SM[i].is_bind = 0;                                    // Not bound
        SM[i].process_id = -1;                                // No process is using it
        SM[i].upd_socket_id = socket(AF_INET, SOCK_DGRAM, 0); // UDP socket created to avoid BADFD error
        SM[i].sendingBuffer.send_buffer_sz = SEND_BUF_SIZE;   // Size of the Sending Window
        SM[i].sendingBuffer.size = 0;                         // Number of messages in the buffer
        SM[i].sendingBuffer.left = 1;                         // Left pointer
        SM[i].sendingBuffer.right = 1;                        // Right pointer
        SM[i].ReceivingWindow.recv_start = 1;
        SM[i].ReceivingWindow.recv_end = 10;
        SM[i].ReceivingWindow.size = RECV_BUF_SIZE;
        SM[i].ReceivingWindow.last_acked = -1;
        SM[i].ReceivingBuffer.write_pointer = 1;  // Application is Expecting 1st message
        SM[i].ReceivingBuffer.recv_pointer = 1;   // Application is Expecting 1st message
        SM[i].ReceivingBuffer.recv_buff_size = 0; // Important to Distinguish between full and empty window
        SM[i].sendingWindow.size = 0;             // Important to Distinguish between full and empty window
        SM[i].sendingWindow.send_base = 1;
        SM[i].sendingWindow.next_seq = 1;
        for (int j = 1; j <= NUM_SEQ; j++)
        {
            SM[i].sendingWindow.wndw[j] = -1;         // Not yet sent
            SM[i].sendingWindow.lastSendTime[j] = -1; // Not yet sent
            SM[i].ReceivingWindow.wndw[j] = -1;       // Not yet received
        }
        for (int j = 1; j <= SEND_BUF_SIZE; j++)
        {
            SM[i].sendingBuffer.lengthOfMessageSent[j] = -1; // Not yet sent
        }
        for (int j = 1; j <= RECV_BUF_SIZE; j++)
        {
            SM[i].ReceivingBuffer.recv_buffer_valid[j] = -1;   // Not yet received
            SM[i].ReceivingBuffer.lengthOfMessageRecv[j] = -1; // Not yet received
        }
    }

    // Message for the User
    printf("initksocket : Shared Memory and Semaphore Created\n");

    // Create the Thread R,Thread S,Thread G
    pthread_t threadR, threadS;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    if (pthread_create(&threadR, &attr, ThreadR, NULL) != 0)
        perror("pthread_create for ThreadR failed");
    if (pthread_create(&threadS, &attr, ThreadS, NULL) != 0)
        perror("pthread_create for ThreadS failed");
    // if (pthread_create(&threadG, &attr, ThreadG, NULL) != 0)
    //     perror("pthread_create for ThreadG failed");

    while (1)
    {
        P(bind_mutex);
        P(sm_mutex);
        // I have got a signal to bind so chech which of the ktpSocket is not bind yet...
        for (int i = 1; i <= N; i++)
        {
            if (SM[i].is_active == 1 && SM[i].is_bind == 0)
            {
                /*Bind to Source Ip/Port*/
                SM[i].is_bind = 1;
                bind(SM[i].upd_socket_id, (struct sockaddr *)&SM[i].source_addr, (socklen_t)sizeof(SM[i].source_addr));
                break;
            }
        }
        V(sm_mutex);
    }

    // Never exected
    return 0;
}