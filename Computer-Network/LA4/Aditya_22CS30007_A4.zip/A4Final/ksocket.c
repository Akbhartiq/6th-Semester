#include "ksocket.h"
#include <assert.h>

// Shared Memory Structure
_ktpSocket *SM;

// Semaphore and shared Memory variables
int sem_mutex;
int bind_mutex;
struct sembuf pop, vop;

// Error code
int error_code = 0;

// Function to get the shared Memory and Semaphore
void get_shared_resources()
{
    // Get the Mutex for the shared Memory
    int sm_mutex_key = ftok("/", 'A');
    if (sm_mutex_key == -1)
    {
        perror("get_shared_resources : ftok");
        exit(1);
    }
    sem_mutex = semget(sm_mutex_key, 1, 0666);
    if (sem_mutex == -1)
    {
        perror("get_shared_resources : semget");
        exit(1);
    }

    // Bind_mutex_key
    int bind_mutex_key = ftok("/", 'B');
    if (bind_mutex_key == -1)
    {
        perror("get_shared_resources : ftok");
        exit(1);
    }
    bind_mutex = semget(bind_mutex_key, 1, 0666);
    if (bind_mutex == -1)
    {
        perror("get_shared_resources : semget");
        exit(1);
    }

    // Get the shared Memory
    int sm_key = ftok("/", 'C');
    if (sm_key == -1)
    {
        perror("get_shared_resources : ftok");
        exit(1);
    }
    int sm_id = shmget(sm_key, (N + 1) * sizeof(_ktpSocket), 0666);
    if (sm_id == -1)
    {
        perror("get_shared_resources : shmget");
        exit(1);
    }

    // Attach to the shared Memory
    SM = (_ktpSocket *)shmat(sm_id, NULL, 0);
    if (SM == (_ktpSocket *)-1)
    {
        perror("get_shared_resources : shmat");
        exit(1);
    }

    // Initialize the pop,vop
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;
}

// Function to check if an entry is availabe or not
int is_FreeEntry()
{
    for (int i = 1; i <= N; i++)
    {
        if (SM[i].is_active == 0)
        {
            /*Free to Use*/
            printf("Free Space Available at %d\n", i);
            return i;
        }
    }
    printf("No Space Available\n");
    return -1;
}

// Function Definations
int k_socket(int _domain, int _type, int _protocol)
{
    // Get the shared Memory and Semaphore
    get_shared_resources();

    // Accept only SOCK_KTP
    if (_type != SOCK_KTP)
    {
        return -1;
    }

    // Check if the entry is available
    P(sem_mutex);
    int i = is_FreeEntry();
    if (i == -1)
    {
        error_code = ENOSPACE;
        V(sem_mutex);
        return -1;
    }

    /*Free space is Available*/
    SM[i].is_active = 1;
    SM[i].process_id = getpid();
    V(sem_mutex);
    return i;
}
int k_bind(char src_ip[], uint16_t src_port, char dest_ip[], uint16_t dest_port)
{
    // Get the shared Memory and Semaphore
    get_shared_resources();

    // Get the current process id
    pid_t pid = getpid();

    // Wait on sem_mutex
    P(sem_mutex);

    // Find the socket with the given process id
    int i;
    for (i = 1; i <= N; i++)
    {
        if (SM[i].is_active && SM[i].process_id == pid)
        {
            break;
        }
    }

    // If no socket is found
    if (i == N + 1)
    {
        error_code = BINDERROR;
        V(sem_mutex);
        return -1;
    }

    // Else
    SM[i].source_addr.sin_family = AF_INET;
    SM[i].source_addr.sin_port = htons(src_port);
    SM[i].source_addr.sin_addr.s_addr = inet_addr(src_ip);

    // Update the Destination
    SM[i].dest_addr.sin_family = AF_INET;
    SM[i].dest_addr.sin_port = htons(dest_port);
    SM[i].dest_addr.sin_addr.s_addr = inet_addr(dest_ip);

    V(sem_mutex);
    V(bind_mutex);
    return 0; // Success
}
ssize_t k_sendto(int sockfd, const void *buf, size_t len, int flags,
                 const struct sockaddr *dest_addr, socklen_t addrlen)
{
    // Get the shared Memory and Semaphore
    get_shared_resources();

    // printf("******Waiting on sem_mutex******\n");
    // Wait on sem_mutex
    P(sem_mutex);
    // printf("******Done Waiting on sem_mutex******\n");

    // Check the status of the sockfd
    if (sockfd < 1 || sockfd > N || SM[sockfd].is_active == 0)
    {
        error_code = BADFD;
        V(sem_mutex);
        return -1;
    }

    // Else check if the Destination matches
    if (SM[sockfd].dest_addr.sin_family != dest_addr->sa_family ||
        SM[sockfd].dest_addr.sin_port != ((struct sockaddr_in *)dest_addr)->sin_port ||
        memcmp(&SM[sockfd].dest_addr.sin_addr, &((struct sockaddr_in *)dest_addr)->sin_addr, sizeof(struct in_addr)) != 0)
    {
        error_code = ENOTBOUND;
        V(sem_mutex);
        return -1;
    }

    // Else check if Free space available in the sending buffer
    if (SM[sockfd].sendingBuffer.size == SEND_BUF_SIZE)
    {
        printf("No Space Available in the Sending Buffer\n");
        error_code = ENOSPACE;
        V(sem_mutex);
        return -1;
    }

    // printf("Space is available in the Sending Buffer\n");

    // Else copy the data to the sending buffer
    memcpy(SM[sockfd].sendingBuffer.send_buffer[SM[sockfd].sendingBuffer.right], buf, len);

    // printf("Sending Buffer: %s\n", SM[sockfd].sendingBuffer.send_buffer[SM[sockfd].sendingBuffer.right]);

    // Update the sending buffer
    SM[sockfd].sendingBuffer.size++;
    SM[sockfd].sendingBuffer.right++;
    if (SM[sockfd].sendingBuffer.right == SEND_BUF_SIZE + 1)
    {
        SM[sockfd].sendingBuffer.right = 1;
        // printf("Making the Sending Buffer Right Pointer wrap around\n");
    }

    // Release the mutex
    V(sem_mutex);
    return len;
}
ssize_t k_recvfrom(int sockfd, void *buf, size_t len, int flags,
                   struct sockaddr *src_addr, socklen_t *addrlen)
{
    // Get the shared Memory and Semaphore
    get_shared_resources();

#ifdef DEBUG
    // printf("*********Waiting on sem_mutex******\n");
#endif
    // Wait on sem_mutex
    P(sem_mutex);

    // printf("For i = %d\n", sockfd);
    // printf("Receiving Buffer Size : %d\n", SM[sockfd].ReceivingBuffer.recv_buff_size);

#ifdef DEBUG
    // printf("*********Done Waiting on sem_mutex******\n");
#endif
    // Check if any data is available in the receiving buffer
#ifdef DEBUG
    // printf("Recv_pointer = %d\n", SM[sockfd].ReceivingBuffer.recv_pointer);
    // printf("SM[sockfd].ReceivingBuffer.recv_buffer_valid[SM[sockfd].ReceivingBuffer.recv_pointer] = %d\n", SM[sockfd].ReceivingBuffer.recv_buffer_valid[SM[sockfd].ReceivingBuffer.recv_pointer]);
#endif
    if (SM[sockfd].ReceivingBuffer.recv_buffer_valid[SM[sockfd].ReceivingBuffer.recv_pointer] == -1)
    {
#ifdef DEBUG
        // printf("Am I executing\n");
#endif
        error_code = ENOMESSAGE;
        V(sem_mutex);
        return -1;
    }

    // Else copy the first Message to the buffer(len == SM[sockfd].ReceivingBuffer.lengthOfMessageRecv[SM[sockfd].ReceivingBuffer.recv_pointer])
    memcpy(buf, SM[sockfd].ReceivingBuffer.recv_buffer[SM[sockfd].ReceivingBuffer.recv_pointer], len);

    // Update the receiving buffer
    SM[sockfd].ReceivingBuffer.lengthOfMessageRecv[SM[sockfd].ReceivingBuffer.recv_pointer] = -1;
    SM[sockfd].ReceivingBuffer.recv_buffer_valid[SM[sockfd].ReceivingBuffer.recv_pointer] = -1;
    SM[sockfd].ReceivingBuffer.recv_pointer++;
    if (SM[sockfd].ReceivingBuffer.recv_pointer == RECV_BUF_SIZE + 1)
    {
        SM[sockfd].ReceivingBuffer.recv_pointer = 1;
    }
    SM[sockfd].ReceivingBuffer.recv_buff_size--;

    // Release the Mutex
    V(sem_mutex);

    return len;
}
int k_close(int sockfd)
{
    // Get shared Memory and Semaphore
    get_shared_resources();

    // Wait on sem_mutex
    P(sem_mutex);

    // Check if the sockfd is valid
    if (sockfd < 1 || sockfd > N)
    {
        error_code = BADFD;
        V(sem_mutex);
        return -1;
    }

    // Else close the socket
    SM[sockfd].is_active = 0;                                // Free to use
    SM[sockfd].is_bind = 0;                                  // Not bound
    SM[sockfd].process_id = -1;                              // No process is using it
    SM[sockfd].sendingBuffer.send_buffer_sz = SEND_BUF_SIZE; // Size of the Sending Window
    SM[sockfd].sendingBuffer.size = 0;                       // Number of messages in the buffer
    SM[sockfd].sendingBuffer.left = 1;                       // Left pointer
    SM[sockfd].sendingBuffer.right = 1;                      // Right pointer
    SM[sockfd].ReceivingWindow.recv_start = 1;
    SM[sockfd].ReceivingWindow.recv_end = 10;
    SM[sockfd].ReceivingWindow.size = RECV_BUF_SIZE;
    SM[sockfd].ReceivingWindow.last_acked = -1;
    SM[sockfd].ReceivingBuffer.write_pointer = 1;  // Application is Expecting 1st message
    SM[sockfd].ReceivingBuffer.recv_pointer = 1;   // Application is Expecting 1st message
    SM[sockfd].ReceivingBuffer.recv_buff_size = 0; // Important to Distinguish between full and empty window
    SM[sockfd].sendingWindow.size = 0;             // Important to Distinguish between full and empty window
    SM[sockfd].sendingWindow.send_base = 1;
    SM[sockfd].sendingWindow.next_seq = 1;
    for (int j = 1; j <= NUM_SEQ; j++)
    {
        SM[sockfd].sendingWindow.wndw[j] = -1;         // Not yet sent
        SM[sockfd].sendingWindow.lastSendTime[j] = -1; // Not yet sent
        SM[sockfd].ReceivingWindow.wndw[j] = -1;       // Not yet received
    }
    for (int j = 1; j <= SEND_BUF_SIZE; j++)
    {
        SM[sockfd].sendingBuffer.lengthOfMessageSent[j] = -1; // Not yet sent
    }
    for (int j = 1; j <= RECV_BUF_SIZE; j++)
    {
        SM[sockfd].ReceivingBuffer.recv_buffer_valid[j] = -1;   // Not yet received
        SM[sockfd].ReceivingBuffer.lengthOfMessageRecv[j] = -1; // Not yet received
    }

    // Release the Mutex
    V(sem_mutex);

    return 0;
}