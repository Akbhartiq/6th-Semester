#ifndef KSOCKET_H
#define KSOCKET_H

// In-build Headers
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/sem.h>
#include <pthread.h>
#include <signal.h>
#include <sys/shm.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Custom socket type for KTP
#define SOCK_KTP 1234

// Macros Related to size
#define SEND_BUF_SIZE 10
#define RECV_BUF_SIZE 10
#define NUM_SEQ 128
#define MESSAGE_SIZE 512 // In bytes(Including the Null Character of Message)

// T,p,N for sliding window Protocol
#define T 2
#define p 0.5
#define N 2

// Semaphore Methods
#define P(s) semop(s, &pop, 1) // Wait Method for the Semaphore
#define V(s) semop(s, &vop, 1) // Signal Method for the Semaphore

// Boolean
#define TRUE 1
#define FALSE 0

// Error Codes
extern int error_code;
#define ENOSPACE 1000
#define BINDERROR 1001
#define ENOTBOUND 1002
#define BADFD 1003
#define ENOMESSAGE 1004

// Sending Window[1..NUM_SEQ]
typedef struct
{
    int wndw[NUM_SEQ + 1];
    int size; // Already sent(but not yet acked)
    int send_base;
    int next_seq;
    time_t lastSendTime[NUM_SEQ + 1];
} _swnd;

// Sending Buffer
typedef struct
{
    char send_buffer[SEND_BUF_SIZE + 1][MESSAGE_SIZE];
    int size;           // Number of messages in the buffer
    int left;           // Left pointer
    int right;          // Right pointer
    int send_buffer_sz; // Size of sending window
    int lengthOfMessageSent[SEND_BUF_SIZE + 1];
} _sendBuf;

// Receiving Window[1..NUM_SEQ]
typedef struct
{
    int wndw[NUM_SEQ + 1];
    int size;
    int recv_start;
    int recv_end;
    int last_acked;
} _rwnd;

// Receiving Buffer
typedef struct
{
    char recv_buffer[RECV_BUF_SIZE + 1][MESSAGE_SIZE];
    int recv_pointer;   // Which one to Recv for Application
    int write_pointer;  // Where to write for the Thread R
    int recv_buff_size; // Number of Messages in the buffer
    int recv_buffer_valid[RECV_BUF_SIZE + 1];
    int lengthOfMessageRecv[RECV_BUF_SIZE + 1];
    int nospace; // Nospace
} _recvBuf;

// socket structure
typedef struct
{
    int is_active;
    int is_bind;
    pid_t process_id;
    int upd_socket_id;
    struct sockaddr_in source_addr;
    struct sockaddr_in dest_addr;
    _sendBuf sendingBuffer;
    _recvBuf ReceivingBuffer;
    _swnd sendingWindow;
    _rwnd ReceivingWindow;
} _ktpSocket;

// Packet Structure
typedef struct
{
    int is_data; // 1 for data , 0 for ack
    int seq_no;
    int updated_recv_window_size;
    char data[MESSAGE_SIZE];
} _packet;

// Function prototypes
int k_socket(int _domain, int _type, int _protocol);
int k_bind(char src_ip[], uint16_t src_port, char dest_ip[], uint16_t dest_port);
ssize_t k_sendto(int sockfd, const void *buf, size_t len, int flags,
                 const struct sockaddr *dest_addr, socklen_t addrlen);
ssize_t k_recvfrom(int sockfd, void *buf, size_t len, int flags,
                   struct sockaddr *src_addr, socklen_t *addrlen);
int k_close(int sockfd);
int dropMessage();

#endif // KSOCKET_H















