/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
Assignment 5 Submission
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#define PORT 5000
#define MAX_LINE 100
#define BUFFER_SIZE 13
#define FETCH_COUNTER 10
#define SERVER_ERROR 11
#define P 0

/*My Recvall Function*/
int recvall(int _socket, char _buffer[], int _len, int _flag)
{
    /*Recv Untill you get the $ at the End*/
    int idx = 0;
    int fetchCnt = 0;
    char _tempBuff[MAX_LINE];
    do
    {
        int lenRecv = recv(_socket, _tempBuff, _len, _flag);
        // printf("Inside recvall lenRecv = %d\n", lenRecv);
        if (lenRecv == 0)
        {
            return 0;
        }
        if (lenRecv == -1 && (errno == EWOULDBLOCK || errno == EAGAIN))
        {
            /*Check If you have Received Something...*/
            if (fetchCnt > FETCH_COUNTER)
            {
                /*Malicious Client : Not Sticking to the Protocol...*/
                errno = SERVER_ERROR;
                return -1;
            }
            fetchCnt++;
            sleep(1);
            continue;
        }
        if (lenRecv > 0)
        {
            /*Avoid initial Null chars...*/
            int null_idx = 0;
            while (null_idx < lenRecv)
            {
                if (_tempBuff[null_idx] == '\0')
                    null_idx++;
                else
                    break;
            }
            strncpy(_buffer + idx, _tempBuff + null_idx, lenRecv - null_idx);
            idx += lenRecv - null_idx;
        }
        /*Perform End of Message Check...*/
        int dollar_flag = 0;
        for (int i = 0; i < lenRecv; i++)
        {
            if (_tempBuff[i] == '$')
            {
                dollar_flag = 1;
            }
        }
        /*End Of Message...*/
        if (dollar_flag)
        {
            _buffer[idx] = '\0';
            return idx;
        }
    } while (1);

    return -1; // Never Executed...
}

/*send all function...*/
int func(int sockfd, const char *buffer, size_t length)
{
    size_t total_sent = 0; // Bytes successfully sent
    ssize_t bytes_sent;    // Return value of send()
    length = sizeof(buffer);

    while (total_sent < length)
    {
        bytes_sent = send(sockfd, buffer + total_sent, length - total_sent, 0);

        if (bytes_sent > 0)
        {
            total_sent += bytes_sent; // Update the total bytes sent
        }
        else if (bytes_sent == -1 && (errno == EWOULDBLOCK || errno == EAGAIN))
        {
            // Buffer full, retry after a small delay
            usleep(1000); // 1ms sleep to avoid busy-wait
        }
        else
        {
            // Error in sending
            perror("send failed");
            return -1;
        }
    }
    return 0; // Success
}

/*solve task*/
int solve(char _task[])
{
    /*Declare the operands...*/
    char _left[MAX_LINE];
    char _right[MAX_LINE];
    memset(_left, '\0', MAX_LINE);
    memset(_right, '\0', MAX_LINE);
    int _leftIdx = 0;
    int _rightIdx = 0;
    int _flag = 0;
    char op;
    /*Get the operators and operands..*/
    for (int i = 0; i < strlen(_task); i++)
    {
        if (_task[i] == ' ')
            continue;

        if (_flag == 0 && _task[i] <= '9' && _task[i] >= '0')
        {
            _left[_leftIdx++] = _task[i];
        }
        else if (_flag == 1 && _task[i] <= '9' && _task[i] >= '0')
        {
            _right[_rightIdx++] = _task[i];
        }
        else
        {
            if (_task[i] != '$' && _task[i] != '\n')
                op = _task[i];
            _flag = 1;
        }
    }

    /*Convert them to Int...*/
    int left = atoi(_left);
    int right = atoi(_right);

    switch (op)
    {
    case '+':
        return left + right;
    case '-':
        return left - right;
    case '/':
        return left / right;
    case '*':
        return left * right;
    }

    return -1; // Never Executed...
}

int main()
{

    int sockfd; // File Descriptor for the Socket

    // server address
    struct sockaddr_in serv_addr;

    /* Open a socket... */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("client : Unable to create socket\n");
        exit(0);
    }

    /*Mark the socket as non-blocking...*/
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1)
    {
        perror("fcntl : F_GETFL failed");
        exit(1);
    }

    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        perror("fcntl F_SETFL O_NONBLOCK failed");
        exit(1);
    }

    printf("Socket set to non-blocking... mode\n");

    // Feed the info.. of the server to connect
    serv_addr.sin_family = AF_INET;              // IP4
    inet_aton("127.0.0.1", &serv_addr.sin_addr); // IP adddress of the Server
    serv_addr.sin_port = htons(PORT);            // Port: 5000

    // Trying to connect(By this time server must be listening.. then only this will work)

    do
    {
        int retval = (connect(sockfd, (struct sockaddr *)&serv_addr,
                              sizeof(serv_addr)));
        if (retval == -1 && errno != EINPROGRESS)
        {

            perror("Unable to connect to server\n");
            exit(0);
        }
        else if (retval == -1)
        {
            printf("Trying to Reconnect\n");
            sleep(1);
        }
        else
        {
            printf("Hurray: Connected\n");
            break;
        }
    } while (1);

    // Connection Betweent the Server and the Client is Established

    // Seed the Random-number generation
    srand(time(NULL));

    while (1)
    {
        /*Send the Message*/
        char message[MAX_LINE] = "EXIT$";
        int randNum = rand() % 100;
        if (randNum >= P)
            strcpy(message, "GET_TASK$");
        int lenSend = send(sockfd, message, MAX_LINE, 0);
        if (lenSend == -1)
        {
            perror("server : send failed");
            exit(1);
        }
        printf("Message <%s> send ...\n", message);
        if (randNum < P)
        {
            printf("Exiting...\n");
            exit(0);
        }
        char buffer[MAX_LINE];
        int lenRecv = recvall(sockfd, buffer, MAX_LINE, 0);
        if (lenRecv > 0)
        {
            printf("Messge <%s> received\n", buffer);

            /*Check if Exit Message*/
            if (strcmp(buffer, "NO_MORE_TASK$") == 0)
            {
                printf("Exiting...\n");
                exit(0);
            }
            else
            {
                if (strcmp(buffer, "PENDING$") == 0)
                {
                    printf("Pending taks...\n");
                    sleep(5);
                    continue;
                }
            }

            /*Solve the task and Return to the server...*/
            int result = solve(buffer);
            printf("The value of result is %d\n", result);
            /*Send to the Server...*/
            char resMsg[MAX_LINE];
            memset(resMsg, '\0', MAX_LINE);
            sprintf(resMsg, "RESULT %d $", result);
            int lensend = send(sockfd, resMsg, MAX_LINE, 0);
            if (lensend == -1)
            {
                perror("client : send failed");
                exit(1);
            }
        }
        else if (errno == EWOULDBLOCK || errno == EAGAIN)
        {
            // printf("client : recv agian\n");
            sleep(1);
        }
        else
        {
            perror("client : recv failed\n");
            exit(1);
        }
    }

    close(sockfd);

    return 0;
}
