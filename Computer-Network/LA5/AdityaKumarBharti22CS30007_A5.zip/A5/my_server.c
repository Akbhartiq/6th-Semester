/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
Assignment 5 Submission
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <signal.h>
#include <sys/wait.h>

/*Macros...*/
#define PORT 5000
#define MAX_REQ 10
#define BUFFER_SIZE 13
#define MALICIOUS_CLIENT 1024
#define TRIED_TOLERANCE 10
#define MAX_LINE 100
#define MAX_SIZE 100
#define NOTDONE 10
#define ALLOCATED 11
#define COMPLETED 12
#define TWOMSG 13
#define ONEMSG 14
#define LATESOLVERCNT 5

/*struct sem-buf*/
struct sembuf pop, vop;
#define P(s) semop(s, &pop, 1)
#define V(s) semop(s, &vop, 1)

/*Structure For Tasks...*/
typedef struct
{
    int task_id;
    int status;
    int result;
    char arithop[MAX_LINE];
} task;

/*Signal Handler Function...*/
void func_user1()
{
    /*wait for the child exited...*/
    wait(NULL);
    return;
}

/*My Recvall Function*/
int recvall(int _socket, char _buffer1[], char _buffer2[], int _len, int _flag)
{
    /*Recv Untill you get the $ at the End*/
    int idx1 = 0;
    int idx2 = 0;
    int tried = 0;

    /*Init them..*/
    memset(_buffer1, '\0', _len);
    memset(_buffer2, '\0', _len);

    /*Trying to fill the buffer1*/
    int status = 1;

    /*Temp buffer*/
    char _tempBuff[MAX_LINE];

    /*Init it...*/
    memset(_tempBuff, '\0', MAX_LINE);

    /*Working Loop...*/
    do
    {
        /*recv call*/
        int lenRecv = recv(_socket, _tempBuff, _len, _flag);
        if (lenRecv == 0)
        {
            /*Client has Disconnected...*/
            return 0;
        }
        if (lenRecv == -1 && (errno == EWOULDBLOCK || errno == EAGAIN))
        {
            /*Check If you have Received Something...*/
            if (tried > TRIED_TOLERANCE)
            {
                /*Malicious Client : Not Sticking to the Protocol...*/
                errno = MALICIOUS_CLIENT;
                return -1;
            }
            tried++;
            sleep(1);
            memset(_tempBuff, '\0', MAX_LINE);
            continue;
        }
        if (lenRecv > 0)
        {
            /*Avoid Leading Null characters...*/
            int null_idx = 0;
            while (null_idx < lenRecv)
            {
                if (_tempBuff[null_idx] == '\0')
                    null_idx++;
                else
                    break;
            }

            /*Perform Malicious Check...*/
            int dollar_flag = -1;
            for (int i = null_idx; i < lenRecv; i++)
            {
                if (_tempBuff[i] == '$')
                {
                    dollar_flag = i; // Get the $ index
                }
            }

            /*If $ is present*/
            if (dollar_flag != -1)
            {
                /*Trying to the fill the buffer1*/
                if (status == 1)
                {

                    strncpy(_buffer1 + idx1, _tempBuff + null_idx, dollar_flag - null_idx + 1);
                    idx1 += (dollar_flag - null_idx + 1);
                    _buffer1[idx1] = '\0';
                    errno = ONEMSG;
                    status = 2;
                }
                /*Trying to the fill buffer2*/
                else
                {
                    strncpy(_buffer2 + idx2, _tempBuff + null_idx, dollar_flag - null_idx + 1);
                    idx2 += (dollar_flag - null_idx + 1);
                    _buffer2[idx2] = '\0';
                    return idx2;
                }
            }
            else
            {
                if (status == 1)
                {

                    strncpy(_buffer1 + idx1, _tempBuff + null_idx, dollar_flag - null_idx + 1);
                    idx1 += (dollar_flag - null_idx + 1);
                    _buffer1[idx1] = '\0';
                    errno = ONEMSG;
                }
                else
                {
                    strncpy(_buffer2 + idx2, _tempBuff + null_idx, dollar_flag - null_idx + 1);
                    idx2 += (dollar_flag - null_idx + 1);
                    _buffer2[idx2] = '\0';
                }
            }

            /*Second Message Retrieval...*/
            if (dollar_flag == -1)
                continue;

            /*First check if second Message is there or not...*/
            int i = dollar_flag + 1;
            int secondMsg = 0;
            while (i < lenRecv && status == 2)
            {
                if (_tempBuff[i] != '\0')
                {
                    secondMsg = 1;
                    break;
                }
                i++;
            }

            if (secondMsg)
            {
                /*Avoid Null Chars...*/
                strncpy(_buffer2 + idx2, _tempBuff + secondMsg, lenRecv - secondMsg);
                errno = TWOMSG;
                idx2 += lenRecv - secondMsg;
                memset(_tempBuff, '\0', MAX_LINE);
            }
            else
            {
                memset(_tempBuff, '\0', MAX_LINE);
                return idx1; /*Get the Message 1 only...*/
            }
        }
    } while (1);

    return -1; // Never Executed...
}

/*send all function...*/
int func(int sockfd, const char *buffer, size_t length)
{
    size_t total_sent = 0; // Bytes successfully sent
    ssize_t bytes_sent;    // Return value of send()
    length = sizeof(buffer);

    while (total_sent < length)
    {
        bytes_sent = send(sockfd, buffer + total_sent, length - total_sent, 0);

        if (bytes_sent > 0)
        {
            total_sent += bytes_sent; // Update the total bytes sent
        }
        else if (bytes_sent == -1 && (errno == EWOULDBLOCK || errno == EAGAIN))
        {
            // Buffer full, retry after a small delay
            usleep(1000); // 1ms sleep to avoid busy-wait
        }
        else
        {
            // Error in sending
            perror("send failed");
            return -1;
        }
    }
    return 0; // Success
}

/*Get the Result from the RESULT XX...*/
int getResult(char buff[])
{
    /*Retrieve the Index...*/
    int start = -1;
    int end = -1;
    for (int i = 0; i < strlen(buff); i++)
    {
        if (buff[i] <= '9' && buff[i] >= '0')
        {
            if (start == -1)
                start = i;
            end = i;
        }
    }

    /*Conver to Int...*/
    char res[MAX_LINE];
    memset(res, '\0', MAX_LINE);
    int idx = 0;
    for (int i = start; i <= end; i++)
        res[idx++] = buff[i];

    int retval = atoi(res);
    return retval;
}

/*Function to print spaces...*/
void print(int cnt)
{
    while (cnt--)
        printf("\t");
}

/*Driver code here...*/
int main()
{
    /*For printting spacing...*/
    int spacecnt = 0;

    /*Register the SIGNAL handler...*/
    signal(SIGUSR1, func_user1);

    /*semaphores and Shared-Memory Thing...*/
    int task_key = ftok("/", 'A');
    int taskArrId = shmget(task_key, MAX_SIZE * sizeof(task), IPC_CREAT | 0666);
    int sem_key = ftok("/", 'B');
    int semId = semget(sem_key, 1, IPC_CREAT | 0666);

    /*set the semaphore values*/
    semctl(semId, 0, SETVAL, 1);

    /*Init the pop and vop structure*/
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    /*Initialize it...*/
    task *job = (task *)shmat(taskArrId, NULL, 0);

    /*Read the File...*/
    FILE *fptr;
    fptr = fopen("task.txt", "r");
    char line[MAX_LINE];
    memset(line, '\0', MAX_LINE);
    int task_idx = 0;
    while (fgets(line, sizeof(line), fptr))
    {
        /*Eliminate new line char...*/
        if (line[strlen(line) - 1] == '\n')
            line[strlen(line) - 1] = '\0';

        /*Get the taskIndex*/
        job[task_idx].task_id = task_idx;

        /*Init the job*/
        memset(job[task_idx].arithop, '\0', MAX_LINE);
        strcpy(job[task_idx].arithop, line);

        /*Put the $ at the End...*/
        int length = strlen(job[task_idx].arithop);
        job[task_idx].arithop[length] = '$';

        memset(line, '\0', MAX_LINE);
        job[task_idx].status = NOTDONE;
        task_idx++;
    }

    /*Number of Task*/
    int numberOfTasks = task_idx;

    /*Mark Other task as Un-necessary*/
    while (task_idx < MAX_SIZE)
    {
        job[task_idx].task_id = -1;
        job[task_idx].status = COMPLETED;
        task_idx++;
    }

    /*Networks-Things...*/
    int sockfd, newsockfd; /*[socket Descriptors]*/
    int client;
    struct sockaddr_in serveraddr, clientaddr;
    socklen_t cli_addr_len = sizeof(clientaddr);

    /*Create the TCP socket*/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
    {
        perror("server : socket fails");
        exit(1);
    }

    /*Set the socket to be non-blocking...*/
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1)
    {
        perror("fcntl : F_GETFL failed");
        exit(1);
    }

    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        perror("fcntl F_SETFL O_NONBLOCK failed");
        exit(1);
    }

    printf("Socket set to non-blocking mode\n");

    /*Feed the server Info*/
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = INADDR_ANY;
    serveraddr.sin_port = htons(PORT);

    // Bind to the port
    if (bind(sockfd, (struct sockaddr *)&serveraddr, (socklen_t)sizeof(serveraddr)) < 0)
    {
        perror("bind : failed");
        exit(0);
    }

    /*Listen-Queue Length*/
    listen(sockfd, MAX_REQ);

    /*Working Loop*/
    while (1)
    {
        /*Accept Incoming Connection*/
        int clienLen = sizeof(clientaddr);
        newsockfd = accept(sockfd, (struct sockaddr *)&clientaddr, &clienLen);

        /*Failure Message*/
        if (newsockfd < 0)
        {
            sleep(1);
            // printf("No accept request arrived\n");
            continue;
        }

        if (fork() == 0)
        {
            /*myLate solve count*/
            int mylateSolvecnt = 0;

            /*Get the space count from command-channel(parent)*/
            int myspacecnt = spacecnt;

            /*Child Process to Handle this Client*/
            close(sockfd);

            /*Get the Shared Memory and Semaphores...*/
            int task_key = ftok("/", 'A');
            int taskArrId = shmget(task_key, MAX_SIZE * sizeof(task), IPC_CREAT | 0666);
            int sem_key = ftok("/", 'B');
            int semId = semget(sem_key, 1, IPC_CREAT | 0666);

            /*Attach to the Job*/
            task *job = (task *)shmat(taskArrId, NULL, 0);

            /*Make newsockfd non-blocking...*/
            int flags = fcntl(newsockfd, F_GETFL, 0);
            if (flags == -1)
            {
                print(myspacecnt);
                perror("fcntl : F_GETFL failed");
                exit(1);
            }

            if (fcntl(newsockfd, F_SETFL, flags | O_NONBLOCK) == -1)
            {
                print(myspacecnt);
                perror("fcntl F_SETFL O_NONBLOCK failed");
                exit(1);
            }

            /*Get the Port of the Client*/
            if (getpeername(newsockfd, (struct sockaddr *)&clientaddr, &clienLen) == -1)
            {
                print(myspacecnt);
                perror("server : got name failed\n");
                close(newsockfd);
                exit(0);
            }

            /*Conver the IP to string...*/
            char client_ip[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &clientaddr.sin_addr, client_ip, sizeof(client_ip));

            /*Print the Connection Message*/
            print(myspacecnt);
            printf("Client connected from IP:%s , Port:%d \n", client_ip, ntohs(clientaddr.sin_port));

            /*Mar already tasked as 0*/
            int alreadyTasked = 0;
            int taskIdAllocated = -1;

            while (1)
            {
                /*Buffer...*/
                char _buffer1[MAX_LINE];
                char _buffer2[MAX_LINE];
                memset(_buffer1, '\0', MAX_LINE);
                memset(_buffer2, '\0', MAX_LINE);

                /*Waiting to Recv-the Message...*/
                int lenRecv = recvall(newsockfd, _buffer1, _buffer2, MAX_LINE, 0);


                /*Client-Rquest*/
                if (lenRecv > 0)
                {
                    if (errno == TWOMSG)
                    {
                        if (strncmp(_buffer1, "RESULT", 6) == 0)
                        {
                            /*Result Message...*/
                            if (alreadyTasked == 1 && taskIdAllocated != -1)
                            {
                                /*one of job is done...*/
                                P(semId);
                                job[taskIdAllocated].status = COMPLETED;
                                job[taskIdAllocated].result = getResult(_buffer1);
                                print(myspacecnt);
                                printf("client %d : <%s> = <%d>\n", ntohs(clientaddr.sin_port), job[taskIdAllocated].arithop, job[taskIdAllocated].result);
                                alreadyTasked = 0;
                                taskIdAllocated = -1;
                                V(semId);
                            }
                            /*Reset it otherwise also...*/
                            alreadyTasked = 0;
                            taskIdAllocated = -1;
                        }
                        else
                        {
                            /*Error...*/
                            if (alreadyTasked == 1)
                            {
                                P(semId);
                                if (job[taskIdAllocated].status == ALLOCATED)
                                    job[taskIdAllocated].status = NOTDONE;
                                V(semId);
                            }
                            shmdt(job);
                            close(newsockfd);
                            kill(getppid(), SIGUSR1);
                            exit(0);
                        }
                        if (strcmp(_buffer2, "GET_TASK$") == 0)
                        {
                            if (alreadyTasked == 1)
                            {
                                /*Malicious Client*/
                                P(semId);
                                if (job[taskIdAllocated].status == ALLOCATED)
                                    job[taskIdAllocated].status = NOTDONE;
                                V(semId);
                                shmdt(job);
                                close(newsockfd);
                                kill(getppid(), SIGUSR1);
                                exit(0);
                            }
                            /*Get-Request Message...*/
                            P(semId);
                            int isSend = 0;
                            for (int i = 0; i < numberOfTasks; i++)
                            {
                                if (job[i].status == NOTDONE)
                                {
                                    /*Give to the client...*/
                                    int lensend = send(newsockfd, job[i].arithop, MAX_LINE, 0);
                                    print(myspacecnt);
                                    printf("To client %d : <%s> = ?\n", ntohs(clientaddr.sin_port), job[i].arithop);
                                    if (lensend == -1)
                                    {
                                        print(myspacecnt);
                                        perror("server : send failed");
                                        close(newsockfd);
                                        exit(1);
                                    }
                                    isSend = 1;
                                    taskIdAllocated = i;
                                    job[i].status = ALLOCATED;
                                    alreadyTasked = 1;
                                    break;
                                }
                                else
                                {
                                    if (isSend == 0 && job[i].status == ALLOCATED)
                                        isSend = -1;
                                }
                            }
                            if (isSend == 0)
                            {
                                int lensend = send(newsockfd, "NO_MORE_TASK$", strlen("NO_MORE_TASK$"), 0);
                                print(myspacecnt);
                                printf("To client %d : No More Tasks\n", ntohs(clientaddr.sin_port));
                            }
                            if (isSend == -1)
                            {
                                int lensend = send(newsockfd, "PENDING$", strlen("PENDING$"), 0);
                                print(myspacecnt);
                                printf("To client %d : Pending...\n", ntohs(clientaddr.sin_port));
                            }
                            V(semId);
                            if (isSend == 0)
                            {
                                close(newsockfd);
                                kill(getppid(), SIGUSR1);
                                exit(0);
                            }
                            sleep(2); /*Give Enought time to solve...*/
                        }
                        else
                        {
                            if (alreadyTasked == 1)
                            {
                                P(semId);
                                if (job[taskIdAllocated].status == ALLOCATED)
                                    job[taskIdAllocated].status = NOTDONE;
                                taskIdAllocated = -1;
                                alreadyTasked = 0;
                                V(semId);
                            }
                            if (strcmp(_buffer2, "EXIT$") == 0)
                            {
                                print(myspacecnt);
                                printf("client %d : Exiting...\n", ntohs(clientaddr.sin_port));
                            }
                            shmdt(job);
                            close(newsockfd);
                            kill(getppid(), SIGUSR1);
                            exit(0);
                        }
                    }
                    else if (errno == ONEMSG)
                    {
                        /*GET_TASK$*/
                        if (strcmp(_buffer1, "GET_TASK$") == 0)
                        {
                            if (alreadyTasked == 1)
                            {
                                /*Malicious Client*/
                                P(semId);
                                if (job[taskIdAllocated].status == ALLOCATED)
                                    job[taskIdAllocated].status = NOTDONE;
                                taskIdAllocated = -1;
                                alreadyTasked = 0;
                                V(semId);
                                shmdt(job);
                                close(newsockfd);
                                kill(getppid(), SIGUSR1);
                                exit(0);
                            }
                            /*Get-Request Message...*/
                            P(semId);
                            int isSend = 0;
                            for (int i = 0; i < numberOfTasks; i++)
                            {
                                if (job[i].status == NOTDONE)
                                {
                                    /*Give to the client...*/
                                    int lensend = send(newsockfd, job[i].arithop, MAX_LINE, 0);
                                    print(myspacecnt);
                                    printf("To client %d : <%s> = ?\n", ntohs(clientaddr.sin_port), job[i].arithop);
                                    if (lensend == -1)
                                    {
                                        print(myspacecnt);
                                        perror("server : send failed");
                                        exit(1);
                                    }
                                    isSend = 1;
                                    taskIdAllocated = i;
                                    job[i].status = ALLOCATED;
                                    alreadyTasked = 1;
                                    break;
                                }
                                else
                                {
                                    if (isSend == 0 && job[i].status == ALLOCATED)
                                        isSend = -1;
                                }
                            }
                            if (isSend == 0)
                            {
                                int lensend = send(newsockfd, "NO_MORE_TASK$", strlen("NO_MORE_TASK$"), 0);
                                print(myspacecnt);
                                printf("To client %d : No More Tasks\n", ntohs(clientaddr.sin_port));
                            }
                            if (isSend == -1)
                            {
                                int lensend = send(newsockfd, "PENDING$", strlen("PENDING$"), 0);
                                print(myspacecnt);
                                printf("To client %d : Pending...\n", ntohs(clientaddr.sin_port));
                            }
                            V(semId);
                            if (isSend == 0)
                            {
                                close(newsockfd);
                                kill(getppid(), SIGUSR1);
                                exit(0);
                            }
                            sleep(2); // Give Enough time to solve...
                        }
                        else if (strncmp(_buffer1, "RESULT", 6) == 0)
                        {
                            /*Result Message...*/

                            if (alreadyTasked == 1 && taskIdAllocated != -1)
                            {
                                P(semId);
                                job[taskIdAllocated].status = COMPLETED;
                                job[taskIdAllocated].result = getResult(_buffer1);
                                print(myspacecnt);
                                printf("client %d : <%s> = <%d>\n", ntohs(clientaddr.sin_port), job[taskIdAllocated].arithop, job[taskIdAllocated].result);
                                alreadyTasked = 0;
                                taskIdAllocated = -1;
                                V(semId);
                            }
                            alreadyTasked = 0;
                            taskIdAllocated = -1;
                        }
                        else
                        {
                            /*Malicious Client*/
                            if (alreadyTasked == 1)
                            {
                                P(semId);
                                if (job[taskIdAllocated].status == ALLOCATED)
                                    job[taskIdAllocated].status = NOTDONE;
                                V(semId);
                            }
                            if (strcmp(_buffer1, "EXIT$") == 0)
                            {
                                print(myspacecnt);
                                printf("client %d : Exiting...\n", ntohs(clientaddr.sin_port));
                            }
                            shmdt(job);
                            kill(getppid(), SIGUSR1);
                            close(newsockfd);
                            exit(0);
                        }
                    }
                    else
                    {
                        /*Malicious Client*/
                        if (alreadyTasked == 1)
                        {
                            P(semId);
                            if (job[taskIdAllocated].status == ALLOCATED)
                                job[taskIdAllocated].status = NOTDONE;
                            taskIdAllocated = -1;
                            alreadyTasked = 0;
                            V(semId);
                        }
                        shmdt(job);
                        kill(getppid(), SIGUSR1);
                        close(newsockfd);
                        exit(0);
                    }
                }
                else if (lenRecv == 0)
                {
                    /*client has Disconnected...*/
                    if (alreadyTasked == 1)
                    {
                        P(semId);
                        if (job[taskIdAllocated].status == ALLOCATED)
                            job[taskIdAllocated].status = NOTDONE;
                        taskIdAllocated = -1;
                        alreadyTasked = 0;
                        V(semId);
                    }
                    shmdt(job);
                    kill(getppid(), SIGUSR1);
                    close(newsockfd);
                    exit(0);
                }
                else
                {
                    /*Late Solver...*/
                    if (mylateSolvecnt <= LATESOLVERCNT && taskIdAllocated != -1)
                    {
                        mylateSolvecnt++;
                        print(myspacecnt);
                        printf("client %d : Late solver\n", ntohs(clientaddr.sin_port));
                        P(semId);
                        if (job[taskIdAllocated].status == ALLOCATED)
                            job[taskIdAllocated].status = NOTDONE;
                        alreadyTasked = 0;
                        V(semId);
                    }
                    else
                    {
                        print(myspacecnt);
                        printf("Disconnecting from client IP:%s , Port:%d\n", client_ip, ntohs(clientaddr.sin_port));
                        shmdt(job);
                        kill(getppid(), SIGUSR1);
                        close(newsockfd);
                        exit(0);
                    }
                }
            }
        }
        else
        {
            /*Parent will Incrment the spac-count here...*/
            spacecnt++;
        }
    }
}