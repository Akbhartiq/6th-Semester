#!/bin/bash

# Get the current working directory
CWD=$(pwd)
echo "Current Working Directory: $CWD"

# Run make to compile the programs
make || { echo "Make failed! Exiting..."; exit 1; }

# Start the server in a new terminal
gnome-terminal -- bash -c "./server; exec bash" &

# Wait for 1 second
sleep 1

# Start client 3 times in different terminals
for i in {1..3}; do
    gnome-terminal -- bash -c "./client; exec bash" &
done

# Start pclient with arguments 1, 2, and 3 in different terminals
for i in {1..3}; do
    gnome-terminal -- bash -c "./pclient $i; exec bash" &
done

echo "All processes launched successfully!"
