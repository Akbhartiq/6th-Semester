<!-- Author : Aditya Kumar Bharti
Roll   : 22CS30007
Assignment 6 Submission... -->

### Please follow the Command Syntax Properly(Although errors are handled properly...)
### I have implemented this using state...
### state 0 : HELO example.com 
### state 1 : LIST bob@example.com , GET_MAIL bob@example.com $ , MAIL FROM: bob@example.com , QUIT
### state 2 : RCPT TO: alice@example.com  , QUIT
### state 3 : DATA : {This is mail...} , QUIT
### There is no Domain Restriction : Domain of gmail.com can send mail to example.com as well...
### Users and Domains are hardcoded...
### mailbox Directory is also harcoded for simplicity..
### Run ./server {PORT} on 1st terminal
### Run ./client {IP} {PORT} on 2nd terminal