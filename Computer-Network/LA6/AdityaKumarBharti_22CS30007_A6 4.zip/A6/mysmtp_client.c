/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
Assignment 6 Submission
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define PORT 8000
#define MSG_SIZE 100
#define STATUS_OK 200
#define ERR 400
#define NOT_FOUND 401
#define FORBIDDEN 403
#define SERVER_ERR 500
#define UNKNOWN 600

/*Send function*/
int mySend(int _fd, const char *buf, size_t __n, int __flags)
{
    int len = strlen(buf);
    char newMsg[MSG_SIZE];
    memset(newMsg, '\0', MSG_SIZE);
    memcpy(newMsg, buf, len);
    newMsg[len] = '$';
    newMsg[len + 1] = '\0';

    int lenSend = send(_fd, newMsg, MSG_SIZE, __flags);
    if (lenSend < 0)
    {
        perror("server : send failed");
        exit(1);
    }
    return lenSend;
}

/*Receive function*/
int myRecv(int _fd, char *buff, size_t __n, int __flags)
{
    char tempBuff[MSG_SIZE];
    int idx = 0;
    memset(buff, '\0', __n);
    do
    {
        memset(tempBuff, '\0', MSG_SIZE);
        int lenRecv = recv(_fd, tempBuff, __n, __flags);
        if (lenRecv < 0)
        {
            if (errno == EINPROGRESS || errno == EWOULDBLOCK)
            {
                sleep(1);
                continue;
            }
            else
            {
                perror("server : recv failed");
                exit(1);
            }
        }
        else if (lenRecv == 0)
        {
            perror("server : client Disconnected");
            exit(1);
        }
        else
        {
            /*Avoid Leading Null chars...*/
            int null_idx = 0;
            while (null_idx < lenRecv)
            {
                if (tempBuff[null_idx] != '\0')
                    break;
                null_idx++;
            }

            memcpy(buff + idx, tempBuff + null_idx, lenRecv - null_idx);
            idx += (lenRecv - null_idx);

            /*Check if it Contains $*/
            int dollar_flag = 0;
            while (null_idx < lenRecv)
            {
                if (tempBuff[null_idx] == '$')
                {
                    dollar_flag = 1;
                    break;
                }
                null_idx++;
            }
            if (dollar_flag)
                break;
        }
    } while (1);

    /*Extract the Exact Message*/
    int buff_len = strlen(buff);
    buff[buff_len - 1] = '\0';

    return buff_len;
}

/*Decode Response Function*/
int decodeResp(const char *resp)
{
    if (strncmp(resp, "200 OK", 3) == 0)
    {
        return STATUS_OK;
    }
    else if (strncmp(resp, "400 ERR", 3) == 0)
    {
        return ERR;
    }
    else if (strncmp(resp, "401 NOT FOUND", 3) == 0)
    {
        return NOT_FOUND;
    }
    else if (strncmp(resp, "403 FORBIDDEN", 3) == 0)
    {
        return FORBIDDEN;
    }
    else if (strncmp(resp, "500 SERVER ERROR", 3) == 0)
    {
        return SERVER_ERR;
    }
    return UNKNOWN; /*Unknown RESPONSE*/
}

int main(int argc, char *argv[])
{
    int cliSocket;
    struct sockaddr_in serverAddr;

    /*Feed in the serverAddr*/
    serverAddr.sin_family = AF_INET;
    if (inet_pton(AF_INET, argv[1], &serverAddr.sin_addr) < 0)
    {
        perror("client : inet_pton failed");
        exit(1);
    }
    serverAddr.sin_port = htons(argc > 2 ? atoi(argv[2]) : PORT);

    /*Create the socket...*/
    cliSocket = socket(AF_INET, SOCK_STREAM, 0);

    if (cliSocket < 0)
    {
        perror("client : socket failed");
        exit(1);
    }

    /*set the socket to non-blocking mode...*/
    int flags = fcntl(cliSocket, F_GETFL, 0);
    if (flags == -1)
    {
        perror("fcntl : F_GETFL failed");
        exit(1);
    }

    if (fcntl(cliSocket, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        perror("fcntl : F_SETFL failed");
        exit(1);
    }

    printf("socket set to non-blocking mode...\n");

    /*Try to Establish a connection*/
    while (connect(cliSocket, (struct sockaddr *)&serverAddr, (socklen_t)sizeof(serverAddr)) < 0)
    {
        if (errno == EINPROGRESS)
        {
            /*Try again*/
            sleep(1);
            continue;
        }
        else
        {
            perror("client : connect failed");
            exit(1);
        }
    }

    printf("Hurray , Connected to my_smpt server\n");

    /*Working Loop...*/
    while (1)
    {
        /*Prompt the user:*/
        printf("> ");
        fflush(stdout);

        /*Take Input Commands from user...*/
        char buffer[MSG_SIZE];
        memset(buffer, '\0', MSG_SIZE);
        int idx = 0;
        char tempBuff[MSG_SIZE];
        memset(tempBuff, '\0', MSG_SIZE);
        int len = read(STDIN_FILENO, tempBuff, MSG_SIZE);
        if (strncmp(tempBuff, "DATA", 4))
        {
            memcpy(buffer + idx, tempBuff, len);
            idx += len;
        }
        else
        {
            while (1)
            {

                if (strcmp(tempBuff, ".\n") == 0)
                {
                    break;
                }
                else
                {
                    memcpy(buffer + idx, tempBuff, len);
                    idx += len;
                }
                memset(tempBuff, '\0', MSG_SIZE);
                len = read(STDIN_FILENO, tempBuff, MSG_SIZE);
            }
        }

        /*Erase the last new line...*/
        buffer[idx - 1] = '\0';

        /*Got the Message*/
        int lenSend = mySend(cliSocket, buffer, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            perror("client : mySend failed");
            exit(1);
        }

        /*Get the Response from the server*/
        char resp[MSG_SIZE];
        int lenRecv = myRecv(cliSocket, resp, MSG_SIZE, 0);

        switch (decodeResp(resp))
        {
        case STATUS_OK:
            /*Go to Next-Step*/
            printf("%s\n", resp);
            if (strncmp(buffer, "QUIT", 4) == 0)
            {
                close(cliSocket);
                exit(0);
            }
            break;
        case ERR:
            printf("%s\n", resp);
            break;
        case NOT_FOUND:
            printf("%s\n", resp);
            break;
        case FORBIDDEN:
            printf("%s\n", resp);
            break;
        case SERVER_ERR:
            printf("%s\n", resp);
            break;
        case UNKNOWN:
            printf("%s\n", resp);
            break;
        }
    }
}