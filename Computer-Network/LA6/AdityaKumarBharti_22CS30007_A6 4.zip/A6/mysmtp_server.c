/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
Assignment 6 Submission
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/sem.h>
#include <sys/ipc.h>

#define PORT 8000
#define MAX_REQ 10
#define MSG_SIZE 1000

#define numberofDomains 1
#define numberofUsers 2

/*Get the Number of Domains and the Number of Users...*/

/*Global variables...*/
const char *users[] = {"alice@example.com", "bob@example.com"};
const char *domains[] = {"example.com"};

/*Semaphores...*/
int sem_key[numberofUsers];
int semId[numberofUsers];

/*pop,vop*/
struct sembuf pop, vop;

/*wait and signal function...*/
#define P(S) semop(S, &pop, 1)
#define V(S) semop(S, &vop, 1)

/*Function to print spaces...*/
void print(int cnt)
{
    while (cnt--)
        printf("\t");
}

/*Function to get the semId*/
int getsemId(const char *user)
{
    for (int i = 0; i < numberofUsers; i++)
    {
        if (strcmp(users[i], user) == 0)
        {
            return i;
        }
    }
    return -1; // Should never executes...
}

/*Send function*/
int mySend(int _fd, const void *buf, size_t __n, int __flags)
{
    int len = strlen(buf);
    char newMsg[MSG_SIZE];
    memset(newMsg, '\0', MSG_SIZE);
    memcpy(newMsg, buf, len);
    newMsg[len] = '$';
    newMsg[len + 1] = '\0';

    int lenSend = send(_fd, newMsg, MSG_SIZE, __flags);
    if (lenSend < 0)
    {
        perror("server : send failed");
        exit(1);
    }
    return lenSend;
}

/*Receive function*/
int myRecv(int _fd, char *buff, size_t __n, int __flags)
{
    char tempBuff[MSG_SIZE];
    int idx = 0;
    memset(buff, '\0', __n);
    do
    {
        memset(tempBuff, '\0', MSG_SIZE);
        int lenRecv = recv(_fd, tempBuff, __n, __flags);
        if (lenRecv < 0)
        {
            if (errno == EINPROGRESS || errno == EWOULDBLOCK)
            {
                sleep(1);
                continue;
            }
            else
            {
                perror("server : recv failed");
                exit(1);
            }
        }
        else if (lenRecv == 0)
        {
            perror("server : client Disconnected");
            exit(1);
        }
        else
        {
            /*Avoid Leading Null chars...*/
            int null_idx = 0;
            while (null_idx < lenRecv)
            {
                if (tempBuff[null_idx] != '\0')
                    break;
                null_idx++;
            }

            memcpy(buff + idx, tempBuff + null_idx, lenRecv - null_idx);
            idx += (lenRecv - null_idx);

            /*Check if it Contains $*/
            int dollar_flag = 0;
            while (null_idx < lenRecv)
            {
                if (tempBuff[null_idx] == '$')
                {
                    dollar_flag = 1;
                    break;
                }
                null_idx++;
            }
            if (dollar_flag)
                break;
        }
    } while (1);

    /*Extract the Exact Message*/
    int buff_len = strlen(buff);
    buff[buff_len - 1] = '\0';

    return buff_len;
}

/*segregate function...*/
void segregate(char *buff1, char *buff2, const char *msg, int n)
{
    memset(buff1, '\0', MSG_SIZE);
    memset(buff2, '\0', MSG_SIZE);
    memcpy(buff1, msg, n);
    strcpy(buff2, msg + n + 1);
}

/*Send forbidden*/
void sendForbidden(int sockfd)
{
    char resp[MSG_SIZE];
    memset(resp, '\0', MSG_SIZE);
    sprintf(resp, "403 FORBIDDEN");
    int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
    if (lenSend < 0)
    {
        perror("server : mySend failed");
        exit(1);
    }
    printf("Sent 403 FORBIDDEN\n");
    return;
}

/*Send forbidden*/
void sendServerError(int sockfd)
{
    char resp[MSG_SIZE];
    memset(resp, '\0', MSG_SIZE);
    sprintf(resp, "500 SERVER ERROR");
    int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
    if (lenSend < 0)
    {
        perror("server : mySend failed");
        exit(1);
    }
    printf("Sent 500 server error\n");
    return;
}

void sendErr(int sockfd)
{
    char resp[MSG_SIZE];
    memset(resp, '\0', MSG_SIZE);
    sprintf(resp, "400 ERR");
    int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
    if (lenSend < 0)
    {
        perror("server : mySend failed");
        exit(1);
    }
    printf("Sent 400 ERR\n");
    return;
}

/*state-Zero function*/
void handleState_zero(int *statePtr, const char *msg, int sockfd, int space)
{
    char buff1[MSG_SIZE];
    char buff2[MSG_SIZE];
    if (strncmp(msg, "HELO", 4) == 0)
    {
        segregate(buff1, buff2, msg, 4);

        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        /*check buff2 should exits as domain*/
        int exist_flag = 0;
        for (int i = 0; i < numberofDomains; i++)
        {
            if (strncmp(buff2, domains[i], strlen(buff2)) == 0)
            {
                exist_flag = 1;
                break;
            }
        }

        if (exist_flag == 0)
        {
            /*Send the 401 NOT FOUND ERROR*/
            char resp[MSG_SIZE];
            memset(resp, '\0', MSG_SIZE);
            sprintf(resp, "401 DOMAIN NOT FOUND");
            int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
            if (lenSend < 0)
            {
                print(space);
                perror("server : mySend failed");
                exit(1);
            }
            print(space);
            printf("Sent 401 DOMAIN NOT FOUND\n");
            return;
        }
        *statePtr = 1;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 OK");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            print(space);
            perror("server : mySend failed");
            exit(1);
        }
        print(space);
        printf("Sent 200 OK\n");
        return;
    }
    else
    {
        sendForbidden(sockfd);
    }
}

void handleState_one(int *statePtr, const char *msg, int sockfd, char *currSender, int space)
{
    char buff1[MSG_SIZE];
    char buff2[MSG_SIZE];
    if (strncmp(msg, "MAIL FROM:", 10) == 0)
    {
        segregate(buff1, buff2, msg, 10);

        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        memset(currSender, '\0', MSG_SIZE);
        memcpy(currSender, buff2, strlen(buff2));
        int exist_flag = 0;
        for (int i = 0; i < numberofUsers; i++)
        {
            if (strncmp(buff2, users[i], strlen(buff2)) == 0)
            {
                exist_flag = 1;
                break;
            }
        }

        if (exist_flag == 0)
        {
            /*Send the 401 NOT FOUND ERROR*/
            char resp[MSG_SIZE];
            memset(resp, '\0', MSG_SIZE);
            sprintf(resp, "401 USER NOT FOUND");
            int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
            print(space);
            if (lenSend < 0)
            {
                perror("server : mySend failed");
                exit(1);
            }
            printf("Sent 401 USER NOT FOUND\n");
            return;
        }
        *statePtr = 2;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 OK");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        print(space);
        if (lenSend < 0)
        {
            perror("server : mySend failed");
            exit(1);
        }
        printf("Sent 200 OK\n");
        return;
    }
    else if (strncmp(msg, "LIST", 4) == 0)
    {
        segregate(buff1, buff2, msg, 4);
        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        int exist_flag = 0;
        for (int i = 0; i < numberofUsers; i++)
        {
            if (strncmp(buff2, users[i], strlen(buff2)) == 0)
            {
                exist_flag = 1;
                break;
            }
        }

        if (exist_flag == 0)
        {
            /*Send the 401 NOT FOUND ERROR*/
            char resp[MSG_SIZE];
            memset(resp, '\0', MSG_SIZE);
            sprintf(resp, "401 USER NOT FOUND");
            int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
            print(space);
            if (lenSend < 0)
            {
                perror("server : mySend failed");
                exit(1);
            }
            printf("Sent 401 USER NOT FOUND\n");
            return;
        }

        /*wait on appt. mutex*/
        int semidx = getsemId(buff2);
        if (semidx == -1)
        {
            print(space);
            perror("server : getsemId failed");
            exit(1);
        }

        /*wait*/
        // printf("waiting on P(list...)\n");
        P(semId[semidx]);
        // printf("came out of P(list...)\n");

        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);

        /*Open the File and Send the Mail...*/
        memcpy(resp, "200 OK", 6);
        int idx = 6;

        char filePath[2 * MSG_SIZE];
        memset(filePath, '\0', 2 * MSG_SIZE);
        sprintf(filePath, "mailbox/%s", buff2);

        FILE *fptr = fopen(filePath, "r");
        if (fptr == NULL)
        {
            V(semId[semidx]);
            print(space);
            sendServerError(sockfd);
            exit(1);
        }

        int counter = 0;

        char line[MSG_SIZE];
        memset(line, '\0', MSG_SIZE);
        while (fgets(line, sizeof(line), fptr))
        {
            line[strlen(line) - 1] = '\0';
            if (strncmp(line, "from : ", 7) == 0)
            {
                char sender[40];
                memset(sender, '\0', 40);
                memcpy(sender, line + 7, strlen(line) - 7);
                memset(line, '\0', MSG_SIZE);
                fgets(line, sizeof(line), fptr);
                line[strlen(line) - 1] = '\0';
                char date[20];
                memset(date, '\0', 20);
                memcpy(date, line + 7, strlen(line) - 7);
                counter++;

                /*Get this in Message...*/
                char newMailMsg[MSG_SIZE];
                memset(newMailMsg, '\0', MSG_SIZE);
                sprintf(newMailMsg, "\n%d:Email from %s (%s)", counter, sender, date);

                int length = strlen(newMailMsg);
                memcpy(resp + idx, newMailMsg, length);
                idx += length;
            }
            memset(line, '\0', MSG_SIZE);
        }

        if (counter == 0)
        {
            memcpy(resp + idx, "\nNO MAIL FOUND", strlen("\nNO MAIL FOUND"));
            idx += strlen("\nNO MAIL FOUND");
        }

        /*signal*/
        print(space);
        if (counter)
            printf("Sent LIST of mails..\n");
        else
            printf("Sent no mails found\n");
        fclose(fptr);
        V(semId[semidx]);

        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            print(space);
            perror("server : mySend failed");
            exit(1);
        }
        return;
    }
    else if (strncmp(msg, "GET_MAIL", 8) == 0)
    {
        segregate(buff1, buff2, msg, 8);
        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        char email[MSG_SIZE];
        memset(email, '\0', MSG_SIZE);
        int number;

        memset(email, '\0', MSG_SIZE);
        if (sscanf(buff2, "%s %d", email, &number) != 2)
        {
            sendErr(sockfd);
            return;
        }

        // printf("value of number is : %d\n", number);
        int emailNum = number;

        /*wait on appt. mutex*/
        int semidx = getsemId(email);
        if (semidx == -1)
        {
            print(space);
            perror("server : getsemId failed");
            exit(1);
        }

        /*wait*/
        // printf("waiting on P(get_mail...)\n");
        P(semId[semidx]);
        // printf("came out of P(get_mail...)\n");

        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        memcpy(resp, "200 OK\n", 7);
        int idx = 7;

        /*Open the File and Read the Mail...*/
        char filePath[2 * MSG_SIZE];
        memset(filePath, '\0', 2 * MSG_SIZE);
        sprintf(filePath, "mailbox/%s", email);

        FILE *fptr = fopen(filePath, "r");
        if (fptr == NULL)
        {
            V(semId[semidx]);
            print(space);
            sendServerError(sockfd);
            exit(1);
        }

        char line[MSG_SIZE];
        memset(line, '\0', MSG_SIZE);

        // printf("Trying to frame the message...\n");

        while (number && fgets(line, sizeof(line), fptr))
        {
            // printf("outerloop\n");
            if (strncmp(line, "BEGIN$", 6) == 0)
            {
                if (number == 1)
                {
                    memset(line, '\0', MSG_SIZE);
                    while (fgets(line, sizeof(line), fptr))
                    {
                        // printf("inner loop\n");
                        if (strncmp(line, "END$", 4) == 0)
                        {
                            break;
                        }
                        memcpy(resp + idx, line, strlen(line));
                        idx += strlen(line);
                        memset(line, '\0', MSG_SIZE);
                    }
                }
                number--;
            }
        }

        if (emailNum == number)
        {
            memset(resp, '\0', MSG_SIZE);
            memcpy(resp, "401 NOT FOUND", 14);
            idx = 13;
        }

        /*signal*/
        print(space);
        if (emailNum == number)
            printf("Sent Requested email not found\n");
        else
            printf("Sent GET_MAIL %d...\n", emailNum);
        fclose(fptr);
        V(semId[semidx]);

        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            print(space);
            perror("server : mySend failed");
            exit(1);
        }
        return;
    }
    else if (strncmp(msg, "QUIT", 4) == 0)
    {
        *statePtr = 0;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 GOODBYE");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        print(space);
        if (lenSend < 0)
        {
            perror("server : mySend failed");
            exit(1);
        }
        printf("Sent 200 GOODBYE\n");
        close(sockfd);
        exit(0);
    }
    else
    {
        sendForbidden(sockfd);
    }
}
void handleState_two(int *statePtr, const char *msg, int sockfd, char *currReceiver, int space)
{
    char buff1[MSG_SIZE];
    char buff2[MSG_SIZE];
    if (strncmp(msg, "RCPT TO:", 8) == 0)
    {
        segregate(buff1, buff2, msg, 8);
        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        memset(currReceiver, '\0', MSG_SIZE);
        memcpy(currReceiver, buff2, strlen(buff2));

        int exist_flag = 0;
        for (int i = 0; i < numberofUsers; i++)
        {
            if (strncmp(buff2, users[i], strlen(buff2)) == 0)
            {
                exist_flag = 1;
                break;
            }
        }

        if (exist_flag == 0)
        {
            /*Send the 401 NOT FOUND ERROR*/
            char resp[MSG_SIZE];
            memset(resp, '\0', MSG_SIZE);
            sprintf(resp, "401 USER NOT FOUND");
            int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
            print(space);
            if (lenSend < 0)
            {
                perror("server : mySend failed");
                exit(1);
            }
            printf("Sent 401 USER NOT FOUND\n");
            return;
        }
        *statePtr = 3;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 OK");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            print(space);
            perror("server : mySend failed");
            exit(1);
        }
        return;
    }
    else if (strncmp(msg, "QUIT", 4) == 0)
    {
        *statePtr = 0;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 GOODBYE");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        print(space);
        if (lenSend < 0)
        {
            perror("server : mySend failed");
            exit(1);
        }
        printf("Sent 200 GOODBYE\n");
        close(sockfd);
        exit(0);
    }
    else
    {
        sendForbidden(sockfd);
    }
}
void handleState_three(int *statePtr, const char *msg, int sockfd, const char *currSender, const char *currReceiver, int space)
{
    char buff1[MSG_SIZE];
    char buff2[MSG_SIZE];
    if (strncmp(msg, "DATA", 4) == 0)
    {
        segregate(buff1, buff2, msg, 4);

        if (strlen(buff2) == 0)
        {
            sendErr(sockfd);
            return;
        }

        /*Open the File corresponding to Receiver and write the Mail...*/
        /*wait on appt. mutex*/
        int semidx = getsemId(currReceiver);
        if (semidx == -1)
        {
            print(space);
            perror("server : getsemId failed");
            exit(1);
        }

        /*wait*/
        // printf("waiting on P(data...)\n");
        P(semId[semidx]);
        // printf("came out of P(data...)\n");

        char filePath[2 * MSG_SIZE];
        memset(filePath, '\0', 2 * MSG_SIZE);
        sprintf(filePath, "mailbox/%s", currReceiver);

        FILE *fptr = fopen(filePath, "a");
        if (fptr == NULL)
        {
            V(semId[semidx]);
            print(space);
            sendServerError(sockfd);
            exit(1);
        }

        /*To get the time...*/
        time_t t;
        struct tm *tm_info;
        char dateStr[20];

        // Get the Current time
        time(&t);
        tm_info = localtime(&t);

        // Format
        strftime(dateStr, sizeof(dateStr), "%d-%m-%y", tm_info);

        fprintf(fptr, "BEGIN$\n");
        fprintf(fptr, "from : %s\n", currSender);
        fprintf(fptr, "date : %s\n", dateStr);
        fprintf(fptr, "%s\n", buff2);
        fprintf(fptr, "END$\n");

        /*signal*/
        print(space);
        printf("Written the Mail...\n");
        fclose(fptr);
        V(semId[semidx]);

        *statePtr = 1;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 Message Stored SuccessFully");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        print(space);
        if (lenSend < 0)
        {
            perror("server : mySend failed");
            exit(1);
        }
        printf("Send 200 Success Message\n");
    }
    else if (strncmp(msg, "QUIT", 4) == 0)
    {
        *statePtr = 0;
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "200 GOODBYE");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        print(space);
        if (lenSend < 0)
        {
            perror("server : mySend failed");
            exit(1);
        }
        printf("Sent 200 GOODBYE\n");
        close(sockfd);
        exit(0);
    }
    else
    {
        sendForbidden(sockfd);
    }
}

/*know commands function*/
int knownCmd(const char *msg)
{
    if (strncmp(msg, "HELO", 4) == 0)
        return 1;
    if (strncmp(msg, "MAIL FROM:", 10) == 0)
        return 1;
    if (strncmp(msg, "RCPT TO:", 8) == 0)
        return 1;
    if (strncmp(msg, "DATA", 4) == 0)
        return 1;
    if (strncmp(msg, "LIST", 4) == 0)
        return 1;
    if (strncmp(msg, "GET_MAIL", 8) == 0)
        return 1;
    if (strncmp(msg, "QUIT", 4) == 0)
        return 1;

    return 0;
}

/*state-Transition Function...*/
void stateTrans(int *statePtr, const char *msg, int sockfd, char *currSender, char *currReceiver, int space)
{
    /*Print recv Message...*/
    print(space);
    printf("Received Message : %s\n", msg);

    int flag = knownCmd(msg);
    if (flag == 0)
    {
        char resp[MSG_SIZE];
        memset(resp, '\0', MSG_SIZE);
        sprintf(resp, "400 ERR");
        int lenSend = mySend(sockfd, resp, MSG_SIZE, 0);
        if (lenSend < 0)
        {
            print(space);
            perror("server : mySend failed");
            exit(1);
        }
        printf("Sent 400 ERR\n");
        return;
    }

    int val = *statePtr;
    switch (val)
    {
    case 0:
        handleState_zero(statePtr, msg, sockfd, space);
        break;
    case 1:
        handleState_one(statePtr, msg, sockfd, currSender, space);
        break;
    case 2:
        handleState_two(statePtr, msg, sockfd, currReceiver, space);
        break;
    case 3:
        handleState_three(statePtr, msg, sockfd, currSender, currReceiver, space);
        break;
    }
}

int main(int argc, char *argv[])
{

    /*For printing purpose...*/
    int space = 0;

    /*Mutex for common files...*/
    for (int i = 0; i < numberofUsers; i++)
    {
        sem_key[i] = ftok("/", 'A' + i);
        semId[i] = semget(sem_key[i], 1, IPC_CREAT | 0666);
        if (semId[i] < 0)
        {
            perror("server : semget failed");
            exit(1);
        }
        if (semctl(semId[i], 0, SETVAL, 1) < 0)
        {
            perror("server : semctl failed");
            exit(1);
        }
    }

    /*Init pop and vop*/
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    int serverSocket;
    struct sockaddr_in serverAddr;

    /*Feed in the serverAddress...*/
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(argc > 1 ? atoi(argv[1]) : PORT);

    /*Create the socket*/
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0)
    {
        perror("server : socket failed");
        exit(1);
    }

    /*Set the socket to Non-blocking mode....*/
    int flags = fcntl(serverSocket, F_GETFL, 0);
    if (flags == -1)
    {
        perror("fcntl : F_GETFL failed");
        exit(1);
    }

    if (fcntl(serverSocket, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        perror("fcntl F_SETFL O_NONBLOCK failed");
        exit(1);
    }

    printf("server Socket set to non-Blocking Mode\n");

    /*Bind the socket*/
    int retBind = bind(serverSocket, (struct sockaddr *)&serverAddr, (socklen_t)sizeof(serverAddr));
    if (retBind < 0)
    {
        perror("server : Bind failed");
        exit(1);
    }

    /*Listen*/
    if (listen(serverSocket, MAX_REQ) < 0)
    {
        perror("Listen failed");
        exit(1);
    }

    /*working Loop*/
    while (1)
    {
        /*Accept Incoming Connection....*/
        socklen_t serverLen = sizeof(serverAddr);
        int newSocket = accept(serverSocket, (struct sockaddr *)&serverAddr, &serverLen);

        if (newSocket < 0)
        {
            /*No Incomming Connection...*/
            if (errno == EWOULDBLOCK || errno == EAGAIN)
            {
                /*Retry*/
                sleep(1);
                continue;
            }
            else
            {
                perror("server : accept failed");
                exit(1);
            }
        }

        /*Fork a new Process...*/
        if (fork() == 0)
        {
            /*Get Your Space...*/
            int myspace = space;

            /*Set the New socket at non-blocking mode...*/
            int _flags = fcntl(newSocket, F_GETFL, 0);
            if (_flags == -1)
            {
                print(myspace);
                perror("fcntl : F_GETFL failed");
                exit(1);
            }

            if (fcntl(newSocket, F_SETFL, _flags | O_NONBLOCK) == -1)
            {
                print(myspace);
                perror("fcntl F_SETFL O_NONBLOCK failed");
                exit(1);
            }

            /*get the peername*/
            struct sockaddr_in clientAddr;
            socklen_t clientLen = sizeof(clientAddr);
            if (getpeername(newSocket, (struct sockaddr *)&clientAddr, &clientLen) == -1)
            {
                print(myspace);
                printf("server %d : getpeername failed\n", getpid());
                exit(1);
            }

            /*Convert the IP to string*/
            char clientIp[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &clientAddr.sin_addr, clientIp, sizeof(clientIp));

            print(myspace);
            printf("client connected => %s:%d\n", clientIp, ntohs(clientAddr.sin_port));

            /*state of the server*/
            int state = 0;
            char currSender[MSG_SIZE];
            memset(currSender, '\0', MSG_SIZE);
            char currReceiver[MSG_SIZE];
            memset(currReceiver, '\0', MSG_SIZE);

            /*Working Loop of the child...*/
            while (1)
            {
                /*Get the Message from the Client...*/
                char msg[MSG_SIZE];
                int lenRecv = myRecv(newSocket, msg, MSG_SIZE, 0);
                // printf("Recieved : %s\n", msg);
                if (lenRecv < 0)
                {
                    print(myspace);
                    perror("server : myRecv failed");
                    exit(1);
                }
                else if (lenRecv == 0)
                {
                    print(myspace);
                    perror("server : Client Disconnected");
                    exit(1);
                }
                /*Everything is Fine...*/
                stateTrans(&state, msg, newSocket, currSender, currReceiver, myspace);
            }
        }
        else
        {
            space++;
        }
    }
}