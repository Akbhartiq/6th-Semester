/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>
#include <signal.h>

/*Custom Headers*/
#define CUSTOM_PROTOCOL 253
#define MAX_MESSAGE 1024
#define HELLO 0
#define QUERY 1
#define RESPONSE 2
#define SERVER_TIMEOUT 30 // Consider server inactive after 30 seconds
#define MAX_SERVERS 10    // Maximum number of servers to track

/*Type of Query*/
#define CPULOAD 10
#define SYSTIME 11
#define HOSTNAME 12

/*Server Info Structure*/
typedef struct
{
    uint32_t ip;        // IP address of server
    time_t last_seen;   // When was the server last seen
    int active;         // Is the server active
    char hostname[256]; // Hostname (if queried)
    char systime[100];  // System time (if queried)
    char cpuload[20];   // CPU load (if queried)
} ServerInfo;

/*Custom IP Header*/
struct _customIPHdr
{
    uint8_t messageType;
    uint8_t payloadLength;
    uint16_t transactionId;
};

// Global variables
ServerInfo servers[MAX_SERVERS];
int server_count = 0;
int running = 1;

/*Function to create Packets - Corrected version*/
void createPacket(char *payload, char **pkt_ptr, uint32_t saddr, uint32_t daddr, int msgType)
{
    int payload_len = strlen(payload);
    int total_len = sizeof(struct iphdr) + sizeof(struct _customIPHdr) + payload_len + 1;

    // Allocate memory for the entire packet
    char *pkt = (char *)malloc(total_len);
    if (!pkt)
    {
        perror("malloc failed");
        exit(EXIT_FAILURE);
    }

    // Set up IP header
    struct iphdr *ipHeader = (struct iphdr *)pkt;
    ipHeader->ihl = 5;
    ipHeader->version = 4;
    ipHeader->tos = 0;
    ipHeader->tot_len = htons(total_len);
    ipHeader->id = rand() % 100;
    ipHeader->frag_off = 0;
    ipHeader->ttl = 64;
    ipHeader->protocol = CUSTOM_PROTOCOL;
    ipHeader->check = 0;
    ipHeader->saddr = saddr;
    ipHeader->daddr = daddr;

    // Set up custom header
    struct _customIPHdr *custHeader = (struct _customIPHdr *)(pkt + sizeof(struct iphdr));
    custHeader->messageType = msgType;
    custHeader->payloadLength = payload_len;
    custHeader->transactionId = rand() % 65536; // 16-bit random number

    // Copy payload
    memcpy(pkt + sizeof(struct iphdr) + sizeof(struct _customIPHdr), payload, payload_len);

    // Add null terminator after the payload
    (pkt)[sizeof(struct iphdr) + sizeof(struct _customIPHdr) + payload_len] = '\0';

    // Set the output parameter
    *pkt_ptr = pkt;
}

/*Initialize servers array*/
void initializeServers()
{
    for (int i = 0; i < MAX_SERVERS; i++)
    {
        servers[i].ip = 0;
        servers[i].active = 0;
        servers[i].last_seen = 0;
        servers[i].hostname[0] = '\0';
        servers[i].systime[0] = '\0';
        servers[i].cpuload[0] = '\0';
    }
}

/*Find server index by IP*/
int findServerByIP(uint32_t ip)
{
    for (int i = 0; i < MAX_SERVERS; i++)
    {
        if (servers[i].ip == ip && servers[i].active)
        {
            return i;
        }
    }
    return -1;
}

/*Update server status or add new server*/
void updateServerStatus(uint32_t ip)
{
    int index = findServerByIP(ip);

    if (index >= 0)
    {
        // Update existing server
        servers[index].last_seen = time(NULL);
        servers[index].active = 1;
    }
    else
    {
        // Add new server if space available
        for (int i = 0; i < MAX_SERVERS; i++)
        {
            if (!servers[i].active)
            {
                servers[i].ip = ip;
                servers[i].last_seen = time(NULL);
                servers[i].active = 1;
                server_count++;
                printf("New server detected: %s\n", inet_ntoa((struct in_addr){ip}));
                break;
            }
        }
    }
}

/*Process HELLO message*/
void processHello(char *buffer)
{
    struct iphdr *ipHeader = (struct iphdr *)buffer;
    struct _customIPHdr *custHeader = (struct _customIPHdr *)(buffer + sizeof(struct iphdr));

    // Only process if it's a HELLO message
    if (custHeader->messageType == HELLO)
    {
        uint32_t server_ip = ipHeader->saddr;
        updateServerStatus(server_ip);
    }
}

/*Process RESPONSE message*/
void processResponse(char *buffer)
{
    struct iphdr *ipHeader = (struct iphdr *)buffer;
    struct _customIPHdr *custHeader = (struct _customIPHdr *)(buffer + sizeof(struct iphdr));

    // Check if it's a response message
    if (custHeader->messageType == RESPONSE)
    {
        uint32_t server_ip = ipHeader->saddr;
        char *payload = buffer + sizeof(struct iphdr) + sizeof(struct _customIPHdr);
        int index = findServerByIP(server_ip);

        // If we found the server, update its data based on the transaction ID
        if (index >= 0)
        {
            printf("=============================\n");
            printf("Received from %s: %s\n", inet_ntoa((struct in_addr){server_ip}), payload);
            printf("=============================\n");

            // Update server's last_seen time
            servers[index].last_seen = time(NULL);
        }
    }
}

/*Send a query to a specific server*/
void sendQuery(int rawSocket, uint32_t dest_ip, int query_type)
{
    char query[10];
    sprintf(query, "%d", query_type);

    printf("query is %s\n", query);

    char *pkt = NULL;
    createPacket(query, &pkt, htonl(INADDR_ANY), dest_ip, QUERY);

    struct sockaddr_in dest;
    dest.sin_family = AF_INET;
    dest.sin_addr.s_addr = dest_ip;

    int total_size = sizeof(struct iphdr) + sizeof(struct _customIPHdr) + strlen(query) + 1;
    int bytes_send = sendto(rawSocket, pkt, total_size, 0, (struct sockaddr *)&dest, sizeof(dest));

    if (bytes_send < 0)
    {
        perror("sendto failed");
    }
    else
    {
        printf("Query sent to %s\n", inet_ntoa((struct in_addr){dest_ip}));
    }

    printf("++++++++++++++++++++++++++++++++\n");

    free(pkt);
}

/*Print active servers*/
void printActiveServers()
{
    printf("\n=== Active Servers ===\n");
    int active_count = 0;

    for (int i = 0; i < MAX_SERVERS; i++)
    {
        if (servers[i].active)
        {
            active_count++;
            printf("[%d] IP: %s, Last seen: %ld seconds ago\n",
                   i + 1, inet_ntoa((struct in_addr){servers[i].ip}),
                   time(NULL) - servers[i].last_seen);
        }
    }

    if (active_count == 0)
    {
        printf("No active servers found.\n");
    }
    printf("====================\n");
}

/*Remove servers that haven't sent HELLO for a while*/
void cleanupInactiveServers()
{
    time_t current_time = time(NULL);

    for (int i = 0; i < MAX_SERVERS; i++)
    {
        if (servers[i].active && (current_time - servers[i].last_seen) > SERVER_TIMEOUT)
        {
            printf("Server %s is now inactive (timeout)\n", inet_ntoa((struct in_addr){servers[i].ip}));
            servers[i].active = 0;
            server_count--;
        }
    }
}

/*Main function*/
int main()
{
    // Initialize server tracking
    initializeServers();

    // Create raw socket
    int rawSocket = socket(AF_INET, SOCK_RAW, CUSTOM_PROTOCOL);
    if (rawSocket < 0)
    {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    /*Set HDR_INCL and BroadCast Option...*/
    int one = 1;
    if (setsockopt(rawSocket, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0)
    {
        perror("Error setting IP_HDRINCL");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(rawSocket, SOL_SOCKET, SO_BROADCAST, &one, sizeof(one)) < 0)
    {
        perror("Error setting SO_BROADCAST");
        exit(EXIT_FAILURE);
    }

    printf("CLDP Client started. Press Ctrl+C to exit.\n");
    printf("Available commands:\n");
    printf("  list - List active servers\n");
    printf("  query <server_index> <query_type> - Query a server\n");
    printf("    Query types: %d=CPU load, %d=System time, %d=Hostname\n", CPULOAD, SYSTIME, HOSTNAME);
    printf("    server Index = 0 : For BroadCasting Your Query\n");

    // Set up stdin for non-blocking I/O
    fd_set master_fds;
    FD_ZERO(&master_fds);
    FD_SET(STDIN_FILENO, &master_fds);
    FD_SET(rawSocket, &master_fds);
    int max_fd = (STDIN_FILENO > rawSocket) ? STDIN_FILENO : rawSocket;

    char cmd_buffer[256];

    while (running)
    {
        // Clean up inactive servers
        cleanupInactiveServers();

        // Clone the master set for select()
        fd_set read_fds = master_fds;

        // Set timeout for select
        struct timeval timeout;
        timeout.tv_sec = 1; // Check every second
        timeout.tv_usec = 0;

        int activity = select(max_fd + 1, &read_fds, NULL, NULL, &timeout);

        if (activity < 0 && running)
        {
            perror("select error");
            continue;
        }

        // Check if there's user input
        if (FD_ISSET(STDIN_FILENO, &read_fds))
        {
            if (fgets(cmd_buffer, sizeof(cmd_buffer), stdin) == NULL)
            {
                continue;
            }

            // Remove trailing newline
            cmd_buffer[strcspn(cmd_buffer, "\n")] = 0;

            if (strcmp(cmd_buffer, "list") == 0)
            {
                printActiveServers();
            }
            else if (strncmp(cmd_buffer, "query", 5) == 0)
            {
                int server_idx, query_type;
                if (sscanf(cmd_buffer, "query %d %d", &server_idx, &query_type) == 2)
                {
                    if (server_idx == 0)
                    {
                        printf("++++++++++++++++++++++++++++++++\n");
                        printf("BroadCasting My Query\n");
                        sendQuery(rawSocket, INADDR_BROADCAST, query_type);
                    }
                    else if (server_idx >= 1 && server_idx <= MAX_SERVERS && servers[server_idx - 1].active)
                    {
                        if (query_type == CPULOAD || query_type == SYSTIME || query_type == HOSTNAME)
                        {
                            printf("++++++++++++++++++++++++++++++++\n");
                            printf("Sending the Query\n");
                            sendQuery(rawSocket, servers[server_idx - 1].ip, query_type);
                        }
                        else
                        {
                            printf("Invalid query type. Use %d for CPU load, %d for system time, or %d for hostname.\n",
                                   CPULOAD, SYSTIME, HOSTNAME);
                        }
                    }
                    else
                    {
                        printf("Invalid server index or server not active.\n");
                    }
                }
                else
                {
                    printf("Usage: query <server_index> <query_type>\n");
                }
            }
            else
            {
                printf("Unknown command. Available commands: list, query\n");
            }
        }

        // Check if there's data from the socket
        if (FD_ISSET(rawSocket, &read_fds))
        {
            char *buffer = malloc(MAX_MESSAGE + sizeof(struct iphdr) + sizeof(struct _customIPHdr));
            struct sockaddr_in src_addr;
            socklen_t addrlen = sizeof(src_addr);

            int bytes_received = recvfrom(rawSocket, buffer,
                                          MAX_MESSAGE + sizeof(struct iphdr) + sizeof(struct _customIPHdr),
                                          0, (struct sockaddr *)&src_addr, &addrlen);

            if (bytes_received > 0)
            {
                struct iphdr *ipHeader = (struct iphdr *)buffer;

                // Only process CLDP packets
                if (ipHeader->protocol == CUSTOM_PROTOCOL)
                {
                    struct _customIPHdr *custHeader = (struct _customIPHdr *)(buffer + sizeof(struct iphdr));

                    if (custHeader->messageType == HELLO)
                    {
                        processHello(buffer);
                    }
                    else if (custHeader->messageType == RESPONSE)
                    {
                        processResponse(buffer);
                    }
                }
            }

            free(buffer);
        }
    }

    close(rawSocket);
    return 0;
}