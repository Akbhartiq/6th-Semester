/*
Author : Aditya Kumar Bharti
Roll   : 22CS30007
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>
#include <ifaddrs.h>
#include <net/if.h>

/*Custom Headers*/
#define CUSTOM_PROTOCOL 253
#define MAX_MESSAGE 1024
#define HELLO 0
#define QUERY 1
#define RESPONSE 2
#define T 10

/*Type of Query*/
#define CPULOAD 10
#define SYSTIME 11
#define HOSTNAME 12

/*Custom IP Header*/
struct _customIPHdr
{
    uint8_t messageType;
    uint8_t payloadLength;
    uint16_t transactionId;
};

/*Calculate IP Header Checksum*/
unsigned short calculateIPChecksum(struct iphdr *iph)
{
    unsigned short *buf = (unsigned short *)iph;
    unsigned int sum = 0;
    unsigned short result;
    
    // The checksum field must be zero before calculating the checksum
    iph->check = 0;
    
    // Calculate the sum of all 16-bit words in the header
    for (int i = 0; i < iph->ihl * 2; i++) {
        sum += buf[i];
    }
    
    // Add the carry
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    
    // Take the one's complement of the result
    result = ~sum;
    
    return result;
}

/*Function to create Packets - Returns the total packet size*/
int createPacket(char *payload, char **pkt, uint32_t saddr, uint32_t daddr, int msgType)
{
    int payload_len = strlen(payload);

    // Add 1 to the total size to account for null terminator
    int total_size = sizeof(struct iphdr) + sizeof(struct _customIPHdr) + payload_len + 1;

    // Allocate a single contiguous block for entire packet
    *pkt = (char *)malloc(total_size);
    if (!*pkt)
    {
        perror("malloc failed");
        return -1;
    }

    // Clear memory
    memset(*pkt, 0, total_size);

    // Fill IP Header directly in the packet buffer
    struct iphdr *ipHeader = (struct iphdr *)(*pkt);
    ipHeader->ihl = 5;
    ipHeader->version = 4;
    ipHeader->tos = 0;
    ipHeader->tot_len = htons(total_size);
    ipHeader->id = rand() % 65535;
    ipHeader->frag_off = 0;
    ipHeader->ttl = 64;
    ipHeader->protocol = CUSTOM_PROTOCOL;
    ipHeader->check = 0;
    ipHeader->saddr = saddr;
    ipHeader->daddr = daddr;
    
    // Calculate and set the IP header checksum
    ipHeader->check = calculateIPChecksum(ipHeader);

    // Fill Custom Header directly in the packet buffer
    struct _customIPHdr *custHeader = (struct _customIPHdr *)(*pkt + sizeof(struct iphdr));
    custHeader->messageType = msgType;
    custHeader->payloadLength = payload_len;
    custHeader->transactionId = rand() % 65536;

    // Copy payload into packet buffer
    memcpy(*pkt + sizeof(struct iphdr) + sizeof(struct _customIPHdr), payload, payload_len);

    // Add null terminator after the payload
    (*pkt)[sizeof(struct iphdr) + sizeof(struct _customIPHdr) + payload_len] = '\0';

    return total_size;
}

/*Function to announce yourself by sending HELLO*/
void announce(int _socket)
{
    // Get the server's primary IP address
    char ip_str[INET_ADDRSTRLEN];
    uint32_t source_ip = 0;
    struct ifaddrs *ifaddr, *ifa;

    if (getifaddrs(&ifaddr) == -1)
    {
        perror("getifaddrs");
        exit(EXIT_FAILURE);
    }

    // Find first non-loopback IPv4 address
    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr == NULL)
            continue;

        if (ifa->ifa_addr->sa_family == AF_INET)
        {
            struct sockaddr_in *addr = (struct sockaddr_in *)ifa->ifa_addr;

            // Skip loopback addresses
            if (addr->sin_addr.s_addr != htonl(INADDR_LOOPBACK))
            {
                source_ip = addr->sin_addr.s_addr;

                // Convert IP to string
                inet_ntop(AF_INET, &(addr->sin_addr), ip_str, INET_ADDRSTRLEN);
                break;
            }
        }
    }

    freeifaddrs(ifaddr);

    if (source_ip == 0)
    {
        fprintf(stderr, "Could not find a suitable network interface\n");
        strcpy(ip_str, "unknown");
    }

    // Create payload with IP address
    char payload[100];
    sprintf(payload, "%s", ip_str);

    char *pkt = NULL;

    // Create packet and get its size
    int pkt_size = createPacket(payload, &pkt, INADDR_ANY, INADDR_BROADCAST, HELLO);
    if (pkt_size < 0)
    {
        exit(EXIT_FAILURE);
    }

    /*send the HELLO packet*/
    struct sockaddr_in dest;
    dest.sin_family = AF_INET;
    dest.sin_addr.s_addr = INADDR_BROADCAST; // Already in network byte order
    dest.sin_port = 0;                       // Not needed for raw socket

    int bytes_send = sendto(_socket, pkt, pkt_size, 0, (struct sockaddr *)&dest, sizeof(dest));

    if (bytes_send < 0)
    {
        perror("sendto failed");
        free(pkt);
        exit(EXIT_FAILURE);
    }

    printf(">>>HELLO announced to broadcast (%d bytes sent)\n", bytes_send);
    free(pkt); // Free packet memory
}

/*Function to get the Cpu-Load*/
void getCpuLoad(char **payload)
{
    FILE *loadFile = fopen("/proc/loadavg", "r");

    if (loadFile == NULL)
    {
        perror("can't read cpu load");
        *payload = strdup("Error");
        return;
    }

    char loadavg[100];
    if (fgets(loadavg, sizeof(loadavg), loadFile))
    {
        float load;
        sscanf(loadavg, "%f", &load);
        char loadStr[20];
        sprintf(loadStr, "%.2f", load);
        *payload = strdup(loadStr);
    }
    else
    {
        perror("can't read cpu load");
        *payload = strdup("Error");
    }
    fclose(loadFile);
}

/*Function to get the systemTime*/
void getSysTime(char **payload)
{
    time_t currTime = time(NULL);
    if (currTime == -1)
    {
        perror("can't read the sysTime");
        *payload = strdup("Error");
        return;
    }

    char timeStr[100];
    struct tm *time_info = localtime(&currTime);
    strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", time_info);
    *payload = strdup(timeStr);
}

/*Function to get the hostName*/
void getHostName(char **payload)
{
    char host[256];
    if (gethostname(host, sizeof(host)) != 0)
    {
        perror("can't read the hostname");
        *payload = strdup("Error");
        return;
    }
    *payload = strdup(host);
}

void process_Query(int _socket, char *buffer)
{
    struct iphdr *ipHeader = (struct iphdr *)buffer;

    // Check if this is actually our protocol
    if (ipHeader->protocol != CUSTOM_PROTOCOL)
    {
        return; // Not our protocol, ignore
    }

    struct _customIPHdr *custHeader = (struct _customIPHdr *)(buffer + sizeof(struct iphdr));

    // Check if it's a query message
    if (custHeader->messageType != QUERY)
    {
        return; // Not a query, ignore
    }

    /*Payload*/
    char *query = buffer + sizeof(struct iphdr) + sizeof(struct _customIPHdr);

    /*Get the Important Params...*/
    int queryType = atoi(query);
    uint32_t srcAddr = ipHeader->saddr; // Keep in network byte order

    /*Response to be sent*/
    char *payload = NULL;
    char *pkt = NULL;

    printf("++++++++++++++++++++++++++++++++\n");

    /*Process different query types*/
    switch (queryType)
    {
    case CPULOAD:
        printf("Processing CPU load query\n");
        getCpuLoad(&payload);
        break;
    case SYSTIME:
        printf("Processing system time query\n");
        getSysTime(&payload);
        break;
    case HOSTNAME:
        printf("Processing hostname query\n");
        getHostName(&payload);
        break;
    default:
        printf("Unknown query type: %d\n", queryType);
        payload = strdup("Unknown query type");
    }

    printf("Response : %s\n", payload);

    if (!payload)
    {
        payload = strdup("Error processing query");
    }

    /*Create the response packet*/
    int pkt_size = createPacket(payload, &pkt, htonl(INADDR_ANY), srcAddr, RESPONSE);
    if (pkt_size < 0)
    {
        free(payload);
        return;
    }

    /*Send the response packet*/
    struct sockaddr_in clientAddr;
    clientAddr.sin_family = AF_INET;
    clientAddr.sin_addr.s_addr = srcAddr; // Already in network byte order
    clientAddr.sin_port = 0;              // Not needed for raw socket

    int byteSend = sendto(_socket, pkt, pkt_size, 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    if (byteSend < 0)
    {
        perror("sendto failed in response");
    }
    else
    {
        printf("Response sent: %s (%d bytes)\n", payload, byteSend);
    }

    printf("++++++++++++++++++++++++++++++++\n");

    // Clean up
    free(payload);
    free(pkt);
}

int main()
{
    printf("Starting CLDP server...\n");

    // Seed the random number generator
    srand(time(NULL));

    /*Create the Raw socket*/
    int rawSocket = socket(AF_INET, SOCK_RAW, CUSTOM_PROTOCOL);
    if (rawSocket < 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    /*Set HDR_INCL and BroadCast Option...*/
    int one = 1;
    if (setsockopt(rawSocket, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0)
    {
        perror("Error setting IP_HDRINCL");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(rawSocket, SOL_SOCKET, SO_BROADCAST, &one, sizeof(one)) < 0)
    {
        perror("Error setting SO_BROADCAST");
        exit(EXIT_FAILURE);
    }

    printf("CLDP server started. Sending HELLO broadcasts every %d seconds.\n", T);

    /*Keep announcing every T seconds*/
    int firstFlag = 1;
    time_t currTime = time(NULL);
    time_t prevTime = currTime;
    while (1)
    {
        /*Announce after Every T Seconds*/
        currTime = time(NULL);
        if (firstFlag || (currTime - prevTime) >= T)
        {
            prevTime = currTime;
            firstFlag = 0;
            announce(rawSocket);
        }

        /*To keep checking the raw_socket*/
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(rawSocket, &readfds);

        /*Timeout*/
        struct timeval tv;
        tv.tv_sec = 1; // Check every second
        tv.tv_usec = 0;

        /*Check if there is any Incoming Query...*/
        int activity = select(rawSocket + 1, &readfds, NULL, NULL, &tv);

        if (activity < 0)
        {
            perror("select error");
            continue;
        }

        /*If there's data to read*/
        if (activity > 0 && FD_ISSET(rawSocket, &readfds))
        {
            /*Allocate buffer for incoming packet*/
            char buffer[MAX_MESSAGE + sizeof(struct iphdr) + sizeof(struct _customIPHdr)];

            /*Receive the Packet...*/
            struct sockaddr_in clientAddr;
            socklen_t clientLen = sizeof(clientAddr);

            int recv_bytes = recvfrom(rawSocket, buffer, sizeof(buffer), 0,
                                      (struct sockaddr *)&clientAddr, &clientLen);

            if (recv_bytes < 0)
            {
                perror("recvfrom failed");
                continue;
            }

            // Check if this is our own packet
            struct iphdr *ip = (struct iphdr *)buffer;

            // Check message type before processing
            struct _customIPHdr *hdr = (struct _customIPHdr *)(buffer + sizeof(struct iphdr));
            if (hdr->messageType == HELLO)
            {
                continue;
            }

            /*Process the received packet*/
            process_Query(rawSocket, buffer);
        }
    }

    // We never reach here, but good practice
    close(rawSocket);
    return 0;
}