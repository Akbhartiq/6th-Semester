#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

// Important Macros
#define PLAYING 1
#define CATCHMADE 2
#define CATCHMISSED 3
#define OUTOFGAME 4

// Status of the Child
int status;

// My Index as a Child
int chd_idx;

// Number of Sibling
int num_of_sibling;

// Read the Pid of all the Sibling in an array
int sibling[100001];

void printStatus()
{
    // Print the status with a fixed-width field
    switch (status)
    {
    case PLAYING:
        printf("%-10s", "...."); // 10 characters wide
        fflush(stdout);
        break;
    case CATCHMADE:
        printf("%-10s", "CATCH"); // 10 characters wide
        fflush(stdout);
        status = PLAYING;
        break;
    case CATCHMISSED:
        printf("%-10s", "MISS"); // 10 characters wide
        fflush(stdout);
        status = OUTOFGAME;
        break;
    case OUTOFGAME:
        printf("%-10s", ""); // Blank space for OUTOFGAME
        fflush(stdout);
        break;
    }
    fflush(stdout);
}

void sigHandlr_Sigusr1(int sig)
{
    // Print the status
    printStatus();

    // Send the Sigusr1 to Next child
    if (chd_idx < num_of_sibling)
    {
        kill(sibling[chd_idx + 1], SIGUSR1);
    }
    else
    {
        // Open the dummycpid.txt and read Its' PID(Necessary for Cn)
        FILE *dummyfptr;
        const char *dummyfName = "dummycpid.txt";

        dummyfptr = fopen(dummyfName, "r");
        if (dummyfptr == NULL)
        {
            printf("Unable to read the Dummy-cPid\n");
            fflush(stdout);
            exit(0);
        }

        int dummychdPid;
        fscanf(dummyfptr, "%d", &dummychdPid);
        fflush(dummyfptr);

        fclose(dummyfptr);

        // Send the Kill Signal to Dummy child
        kill(dummychdPid, SIGINT);
    }
}

void sigHandlr_Sigusr2(int sig)
{
    // Ball has been thrown to it...
    int num = rand() % 10;
    if (num < 8)
    {
        // Catched(80%)

        // Update the status
        status = CATCHMADE;
        // printf("^%d",chd_idx);
        fflush(stdout);

        // Send the apt.. signal to parent
        kill(getppid(), SIGUSR1);
    }
    else
    {
        // Missed(20%)

        // Update the status
        status = CATCHMISSED;
        // printf("v%d",chd_idx);
        fflush(stdout);

        // Send the apt... signal to parent
        kill(getppid(), SIGUSR2);
    }
}

void sigHandlr_SigInt(int sig)
{
    // If you are still in the Game (You won)
    if (status != OUTOFGAME)
    {
        printf("+++ Child %d: Yay! I am the Winner\n", chd_idx);
        fflush(stdout);
    }
    exit(0); // Exit yourself
}

int main(int argc, char *argv[])
{
    // Register the Signals
    signal(SIGINT, sigHandlr_SigInt);
    signal(SIGUSR1, sigHandlr_Sigusr1);
    signal(SIGUSR2, sigHandlr_Sigusr2);

    if (argc == 1)
    {
        printf("Error : Child Identity Missing\n");
        fflush(stdout);
        exit(0); // Terminate this Process
    }

    // Seed Random Function
    srand(time(NULL) ^ getpid());

    // Mark yourself as playing In Beginning of the Game
    status = PLAYING;

    // Get your Index
    chd_idx = atoi(argv[1]);

    // Sleep Until Parent has written childpid.txt
    sleep(1); // Tentative

    // Open the childpid.txt and read all the PID's of all the Process
    FILE *child_Pid_Ptr;
    const char *childPid_fileName = "childpid.txt";
    child_Pid_Ptr = fopen(childPid_fileName, "r");
    if (child_Pid_Ptr == NULL)
    {
        printf("Unable to open the file : childpid.txt\n");
        fflush(stdout);
        exit(0);
    }

    // Read the number of Sibling
    fscanf(child_Pid_Ptr, "%d", &num_of_sibling);

    // Read into the Sibling array
    for (int i = 1; i <= num_of_sibling; i++)
    {
        fscanf(child_Pid_Ptr, "%d", &sibling[i]);
    }

    // Close the File
    fclose(child_Pid_Ptr);

    while (1)
    {
        pause();
    }
}
