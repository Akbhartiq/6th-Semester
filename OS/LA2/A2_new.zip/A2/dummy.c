#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

// Dummy child Process(Waiting for the SIGINT from the cn)

int main()
{
    pause();
}