#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

#define LIVE 1
#define DEAD 2

// Flag to check if the Sigusr1 signal has been recieved or not
int flag = 0; //(Necessary for synchronization)

// This will keep track of the child who is currenlty facing the ball
int curr = 1;

// Number of Children
int num_of_child;

// Number of children live in the game
int num_of_child_inGame;

struct child
{
    int pid;
    int status;
};

// Child Array
struct child chd_arr[100001];

void sigHandlr_Sigusr1(int sig)
{
    // curr has catched the ball
    flag = 1; // SIGUSR1 has been recieved so get out of the Loop
}

void sigHandlr_Sigusr2(int sig)
{
    // curr has missed the ball
    chd_arr[curr].status = DEAD; // Eliminate it from the Game
    num_of_child_inGame--;       // Reduce the number of live child

    flag = 1; // SIGUSR2 has been recieved so get out of the Loop
}

// Function to print the header dynamically
void printHeader()
{
    printf("  ");
    for (int i = 1; i <= num_of_child; i++)
    {
        printf("%-10d", i); // Fixed width for each column in header
    }
    printf("\n");

    // Separator line
    printf("+");
    for (int i = 0; i < num_of_child; i++)
    {
        for (int j = 0; j < 10; j++)
        { // Fixed width for each column separator
            printf("-");
        }
    }
    printf("+\n");
}

// print back of the each line
void printBack()
{
    // Print a separator line
    printf("|\n+");
    for (int i = 0; i < num_of_child; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            printf("-");
        }
    }
    printf("+\n");
}

// print | for the new line
void printFront()
{
    printf("|");
    fflush(stdout);
}

// Function to print the header dynamically
void printFooter()
{
    printf("  ");
    for (int i = 1; i <= num_of_child; i++)
    {
        printf("%-10d", i); // Fixed width for each column in header
    }
    printf("\n");
}

int main(int argc, char *argv[])
{
    // Registering the Signals
    signal(SIGUSR1, sigHandlr_Sigusr1);
    signal(SIGUSR2, sigHandlr_Sigusr2);

    if (argc == 1)
    {
        printf("Number of child Missing\n");
        fflush(stdout);
        exit(0);
    }

    // Get the Number of child
    num_of_child = atoi(argv[1]);

    if (num_of_child < 1)
    {
        printf("Error: Wrong Input for n\n");
        fflush(stdout);
        exit(0);
    }

    // Create the childpid.txt
    FILE *child_pidPtr;
    const char *chdfile_Name = "childpid.txt";
    child_pidPtr = fopen(chdfile_Name, "w");

    // First line contains Number of child
    fprintf(child_pidPtr, "%d\n", num_of_child);
    fflush(child_pidPtr);

    // Create the child
    for (int i = 1; i <= num_of_child; i++)
    {
        int pid = fork();
        if (pid == 0)
        {
            /*Child Process*/
            char chd_no[11];
            snprintf(chd_no, sizeof(chd_no), "%d", i);
            execlp("./child", "./child", chd_no, NULL);
        }
        else
        {
            /*Parent Process*/
            chd_arr[i].pid = pid;
            chd_arr[i].status = LIVE;

            // Store the pid in the file
            fprintf(child_pidPtr, "%d\n", pid);
            fflush(child_pidPtr);
        }
    }

    // Close the file
    fclose(child_pidPtr);

    printf("Parent: %d child Processes Created\n", num_of_child);
    fflush(stdout);

    printf("Parent: Waiting for child Processes to read child database\n");
    fflush(stdout);

    // Sleep for 2 Seconds(allow child to read childpid.txt)
    sleep(2);

    // Begin the Game
    num_of_child_inGame = num_of_child;

    // Print the Header
    printHeader();

    while (1)
    {
        // Game has End
        if (num_of_child_inGame == 1)
        {
            // PrintFooter
            printFooter();

            // Send the SIGINT signal to everyone
            for (int i = 1; i <= num_of_child; i++)
            {
                kill(chd_arr[i].pid, SIGINT);
                waitpid(chd_arr[i].pid, NULL, 0); // Wait for the each child to get finished
            }
            break;
        }

        // Fork a Dummy-Child
        FILE *fptr;
        const char *fileName = "dummycpid.txt";

        // Open the file
        fptr = fopen(fileName, "w");

        int dummy_cpid = fork();
        if (dummy_cpid == 0)
        {
            /*Child Process*/
            execlp("./dummy", "./dummy", NULL);
        }

        // Write dummy cpid in childpid.txt
        // rewind(fptr);
        fprintf(fptr, "%d\n", dummy_cpid);
        fflush(fptr);

        // Close the File
        fclose(fptr);

        // Throw Ball to the curr child
        kill(chd_arr[curr].pid, SIGUSR2);

        // Take a pause()(only when the SIGUSR1 signal has not been recieved)
        // pause();

        // Replacing Pause with Inf.. loop for the Synchronization Purpose
        while (flag != 1)
        {
            // Infinite loop serving the purpose of Pause()
        }
        flag = 0;

        // Flush for any remaining text
        fflush(stdout);

        // printFront
        printFront();

        // printf("Sending the Signal Once Again\n");

        // Send Sigusr1 to child1
        kill(chd_arr[1].pid, SIGUSR1);

        // Wait for dummy child to finish its execution
        waitpid(dummy_cpid, NULL, 0);

        // printBack
        printBack();

        // printf("\n");
        fflush(stdout);

        // Move to next live child
        curr = (curr + 1) % (num_of_child + 1);
        if (curr == 0)
            curr = 1;
        while (chd_arr[curr].status == DEAD)
        {
            // Move to next child
            curr = (curr + 1) % (num_of_child + 1);
            // Reset to 1 if necessary
            if (curr == 0)
                curr = 1;
        }
    }
}

// Function to print current status of every child
void printCurr()
{
    for (int i = 1; i <= num_of_child; i++)
    {
        printf("(%d)-%d   ", i, chd_arr[i].status);
    }
    printf("\n");
}