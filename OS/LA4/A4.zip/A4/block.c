// --------------------------
// writer : Aditya
// Roll   : 22CS30007
// Date   : Jan 29 2025
// --------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

// A and B
int A[3][3];
int B[3][3];

// Pipes
int selfin;
int selfout;
int r1out;
int r2out;
int c1out;
int c2out;

// Print the Block
void printBlock(int a[][3])
{
    system("clear");
    printf("      +---+---+---+\n");
    printf("      | %c | %c | %c |\n",
           (a[0][0] == 0) ? ' ' : a[0][0] + '0',
           (a[0][1] == 0) ? ' ' : a[0][1] + '0',
           (a[0][2] == 0) ? ' ' : a[0][2] + '0');
    printf("      +---+---+---+\n");
    printf("      | %c | %c | %c |\n",
           (a[1][0] == 0) ? ' ' : a[1][0] + '0',
           (a[1][1] == 0) ? ' ' : a[1][1] + '0',
           (a[1][2] == 0) ? ' ' : a[1][2] + '0');
    printf("      +---+---+---+\n");
    printf("      | %c | %c | %c |\n",
           (a[2][0] == 0) ? ' ' : a[2][0] + '0',
           (a[2][1] == 0) ? ' ' : a[2][1] + '0',
           (a[2][2] == 0) ? ' ' : a[2][2] + '0');
    printf("      +---+---+---+\n");
}

// Handle new game
void handle_n()
{
    // Read the 9 Numbers
    for (int i = 0; i < 9; i++)
    {
        scanf("%d", &A[i / 3][i % 3]);
    }
    // Copy to B
    for (int i = 0; i < 9; i++)
    {
        B[i / 3][i % 3] = A[i / 3][i % 3];
    }

    printBlock(B);
}

// Handle Read-Only  Conflict
int readonlyConflict(int c)
{
    return A[c / 3][c % 3] != 0;
}

// Handle Block-Conflict
int blockConflict(int d, int c)
{
    for (int i = 0; i < 9; i++)
    {
        if (i == c)
            continue;
        if (B[i / 3][i % 3] == d)
            return 1;
    }
    return 0;
}

// Check for ReadConflict
int checkRowConflict(int r, int d)
{
    for (int i = 0; i < 3; i++)
    {
        // printf("%d ", B[r][i]);
        if (B[r][i] == d)
            return 1;
    }
    fflush(stdout);
    return 0;
}

// Check for column Conflict
int checkColConflict(int c, int d)
{
    for (int i = 0; i < 3; i++)
    {
        if (B[i][c] == d)
            return 1;
    }
    return 0;
}

// Get the Row Conflict
void getRowConflict()
{
    // Read from pipe
    int c, d, fd;
    scanf("%d %d %d", &c, &d, &fd);

    // Check for 2 Rows
    int stdoutfd = dup(1);
    close(1);
    if (checkRowConflict(c / 3, d))
    {
        dup(fd);
        printf("%d\n", 1);
    }
    else
    {
        dup(fd);
        printf("%d\n", 0);
    }
    close(1);
    dup(stdoutfd);
}

// Get the column-Conflict
void getColConflict()
{
    // Read from the pipe
    int c, d, fd;
    scanf("%d %d %d", &c, &d, &fd);

    // Check for 2 Neighbours Column
    int stdoutfd = dup(1);
    close(1);
    dup(fd);
    if (checkColConflict(c % 3, d))
    {
        printf("%d\n", 1);
    }
    else
    {
        printf("%d\n", 0);
    }
    close(1);
    dup(stdoutfd);
}

// Send the Row-Conflict to Neigbhours
int sendRowConflict(int r, int i, int d)
{

    int stdoutfd = dup(1);
    close(1);

    // Select which Neighbour to send
    int rowOut = r == 1 ? r1out : r2out;
    dup(rowOut);
    printf("r %d %d %d\n", i, d, selfout);

    // Read the status
    int val;
    scanf("%d", &val);

    close(1);
    dup(stdoutfd);
    return val;
}

// Get column Conflict
int sendColConflict(int c, int i, int d)
{
    int stdoutfd = dup(1);
    close(1);

    // Select which neighbour to send
    int colOut = c == 1 ? c1out : c2out;
    dup(colOut);
    printf("c %d %d %d\n", i, d, selfout);

    // Read the status
    int val;
    scanf("%d", &val);

    close(1);
    dup(stdoutfd);
    return val;
}


// Handle the pcd conflict
void handle_pcd()
{
    // Read in the pipe
    int c, d;
    scanf("%d %d", &c, &d);

    if (readonlyConflict(c))
    {
        printf("Read-only Cell");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }
    if (blockConflict(d, c))
    {
        printf("Block-Conflict");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }
    if (sendRowConflict(1, c / 3, d))
    {
        printf("Row-Conflict");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }
    if (sendRowConflict(2, c / 3, d))
    {
        printf("Row-Conflict");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }
    if (sendColConflict(1, c % 3, d))
    {
        printf("Col-Conflict");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }
    if (sendColConflict(2, c % 3, d))
    {
        printf("Col-Conflict");
        fflush(stdout);
        sleep(1);
        printBlock(B);
        return;
    }

    B[c / 3][c % 3] = d;
    printBlock(B);
}

// Handle Quit
void handle_q()
{
    printf("Bye...\n");
    sleep(1);
    exit(0);
}

// Driver code Begins Here...
int main(int argc, char *argv[])
{
    int blockNo = atoi(argv[1]);

    printf("Block %d ready\n", blockNo);

    sleep(1);

    // Extract the Pipes
    selfin = atoi(argv[2]);
    selfout = atoi(argv[3]);
    r1out = atoi(argv[4]);
    r2out = atoi(argv[5]);
    c1out = atoi(argv[6]);
    c2out = atoi(argv[7]);

    close(0);
    dup(selfin);

    // Command
    char cmd;

    while (1)
    {

        scanf(" %c", &cmd);

        switch (cmd)
        {
        case 'n':
            handle_n();
            break;
        case 'q':
            handle_q();
            break;
        case 'p':
            handle_pcd();
            break;
        case 'r':
            getRowConflict();
            break;
        case 'c':
            getColConflict();
            break;
        }
    }
}