// --------------------------
// writer : Aditya
// Roll   : 22CS30007
// Date   : Jan 29 2025
// --------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "boardgen.c"
#include <sys/wait.h>

// Game-Configuration
int A[9][9]; // Init config..
int S[9][9]; // Solution

// Flag to check if the game has started or not
int gameBegin = 0;

void help()
{
    printf("\n");
    printf("Commands Supported\n");
    printf("\t\tn\t\t\tStart new game\n");
    printf("\t\tp b c d\t\t\tPut digit d [1-9] at cell [0-8] of block b [0-8]\n");
    printf("\t\ts\t\t\tShow Solution\n");
    printf("\t\th\t\t\tPrint this help Message\n");
    printf("\t\tq\t\t\tQuit\n");

    printf("Numbering Schema for Blocks and Cells\n");
    printf("\t\t+---+---+---+\n");
    printf("\t\t| 0 | 1 | 2 |\n");
    printf("\t\t+---+---+---+\n");
    printf("\t\t| 3 | 4 | 5 |\n");
    printf("\t\t+---+---+---+\n");
    printf("\t\t| 6 | 7 | 8 |\n");
    printf("\t\t+---+---+---+\n");

    printf("!! Command pabc <=> p a b c\n\n\n");
}

int get(int i, int j, int a[][9])
{
    int row = 3 * (i / 3);
    int col = 3 * (i % 3);
    int r = j / 3;
    int c = j % 3;
    int nr = row + r;
    int nc = col + c;
    return a[nr][nc];
}

void handle_n(int _pipe[][2], int flag)
{

    // Create the New-Game
    if (flag == 0)
    {
        gameBegin = 1;
        newboard(A, S);
    }
    else
    {
        if (gameBegin == 0)
        {
            printf("Press n to start the Game!!\n");
            return;
        }
    }

    // Close the stdout
    int stdoutfd = dup(1);
    close(1);

    // Pass the Numbers
    for (int i = 0; i < 9; i++)
    {
        dup(_pipe[i][1]); // Must be copied to 1
        printf("n\n");
        for (int j = 0; j < 9; j++)
        {
            if (flag)
                printf("%d ", get(i, j, S));
            else
                printf("%d ", get(i, j, A));
        }
        printf("\n");
        close(1); // Close the 1(so that next dup will again copy at 1)
    }

    // Restore stdout
    dup(stdoutfd); // This must be 1
}

void handle_pbcd(int _pipe[][2], int b, int c, int d)
{
    // See if the Game has Started...
    if (gameBegin == 0)
    {
        printf("Press n to start the Game!!\n");
        return;
    }

    // Close the stdout
    int stdoutfd = dup(1);
    close(1);

    dup(_pipe[b][1]); // Write to bth block pipe
    printf("%c %d %d\n", 'p', c, d);
    close(1);
    dup(stdoutfd);
}

void handle_q(int _pipe[][2])
{
    // Close the stdout
    int stdoutfd = dup(1);
    close(1);

    for (int i = 0; i < 9; i++)
    {
        dup(_pipe[i][1]);
        printf("%c\n", 'q');
        close(1);
    }

    dup(stdoutfd);

    for (int i = 0; i < 9; i++)
    {
        wait(NULL);
    }
    exit(0);
}

// Valid-Block
int validBlock(int b)
{
    return b >= 0 && b <= 8;
}
// Valid-Cell
int validCell(int c)
{
    return c >= 0 && c <= 8;
}
// Valid-Digit
int validDig(int d)
{
    return d >= 1 && d <= 9;
}


// Drive code Begins here...
int main()
{
    // Create the Pipe for the Child
    int _pipe[9][2];

    // Create the Pipe
    for (int i = 0; i < 9; i++)
        pipe(_pipe[i]);

    int cols = 3;                       // 3x3 grid
    int start_x = 900, start_y = 100;   // Slightly shifted right and up
    int x_offset = 320, y_offset = 300; // Spacing between xterms

    for (int i = 0; i < 9; i++)
    {
        int pid = fork();
        if (pid == 0)
        {
            // Calculate row & col index
            int row = i / cols;
            int col = i % cols;

            // Calculate new position
            int x_pos = start_x + col * x_offset;
            int y_pos = start_y + row * y_offset;

            // Get the pipes
            char title[10];
            char blockno[10];
            char _bfdin[10];
            char _bfdout[10];
            char rn1fdout[10];
            char rn2fdout[10];
            char cn1fdout[10];
            char cn2fdout[10];

            sprintf(title, "Block-%d", i);
            sprintf(blockno, "%d", i);
            sprintf(_bfdin, "%d", _pipe[i][0]);
            sprintf(_bfdout, "%d", _pipe[i][1]);
            sprintf(rn1fdout, "%d", _pipe[(i / 3) * 3 + (i + 1) % 3][1]);
            sprintf(rn2fdout, "%d", _pipe[(i / 3) * 3 + (i + 2) % 3][1]);
            sprintf(cn1fdout, "%d", _pipe[i % 3 + ((i - i % 3) + 3) % 9][1]);
            sprintf(cn2fdout, "%d", _pipe[i % 3 + ((i - i % 3) + 6) % 9][1]);

            // Prepare the arguments for execvp
            char *cmd[] = {
                "xterm",
                "-T", title,                                                             // Title is Block
                "-fa", "Monospace",                                                      // Font style
                "-fs", "15",                                                             // Font size
                "-geometry", NULL,                                                       // Geometry (position and size)
                "-bg", "#331100",                                                        // Background color
                "-e", "./block", blockno, _bfdin, _bfdout, rn1fdout, rn2fdout, cn1fdout, // Arguments to ./block
                cn2fdout, NULL                                                           // Terminating null pointer for execvp
            };

            char geometry[20];
            sprintf(geometry, "25X10+%d+%d", x_pos, y_pos);

            cmd[8] = geometry;

            execvp(cmd[0], cmd);

            return 0;
        }
    }

    // Print help Messaage
    help();

    // Pipe Handling...
    char command[100];
    memset(command, '\0', 100);
    char parseCmd[10];
    memset(parseCmd, '\0', 10);
    while (1)
    {
        // Keep Reading the User Input
        printf("Foodoku> ");
        fflush(stdout);
        scanf("%[^\n]", command);

        // Clear the stdin
        getchar();

        // Parse It
        int size = strlen(command);
        int cnt = 0;
        for (int i = 0; i < size; i++)
        {
            if (command[i] != ' ')
            {
                parseCmd[cnt++] = command[i];
            }
        }
        if (cnt == 1)
        {
            switch (parseCmd[0])
            {
            case 'h':
                help();
                break;
            case 'n':
                handle_n(_pipe, 0);
                break;
            case 's':
                handle_n(_pipe, 1);
                break;
            case 'q':
                handle_q(_pipe);
                break;
            default:
                printf("Invalid Command!!\n");
                break;
            }
        }
        else if (cnt == 4)
        {
            // p,b,c,d
            if (parseCmd[0] == 'p')
            {
                int b = parseCmd[1] - '0';
                int c = parseCmd[2] - '0';
                int d = parseCmd[3] - '0';

                if (!validBlock(b))
                {
                    printf("Invalid Command!!\n");
                }
                else if (!validBlock(c))
                {
                    printf("Invalid Command!!\n");
                }
                else if (!validDig(d))
                {
                    printf("Invalid Command!!\n");
                }
                else
                {
                    handle_pbcd(_pipe, b, c, d);
                }
            }
            else
            {
                printf("Invalid Command!!\n");
            }
        }
        else
        {
            /*Invalid Command*/
            printf("Invalid Command!!\n");
        }
    }
}
