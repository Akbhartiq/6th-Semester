#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 2000
#define true 1
#define false 0

// Semaphore Operations
#define P(s) semop(s, &pop, 1)
#define V(s) semop(s, &vop, 1)

// Declaring semaphores and shared memory
// Shared  Semaphores
int mutex, cook;
int waiter[5];
int customer;

// Shared Memory
int *M;

// pop and vop
struct sembuf pop, vop;

// Get hour
int getHour(int min)
{
    switch (min / 60)
    {
    case 0:
        return 11;
    case 1:
        return 12;
    case 2:
        return 1;
    case 3:
        return 2;
    case 4:
        return 3;
    }
    return -1; // Never Executed
}

// GetMinute
int getMin(int min)
{
    return min % 60;
}

// Get Meridian
char getMer(int min)
{
    if (min >= 60)
        return 'p';
    else
        return 'a';
}

// cook code
int cmain(char _cookId)
{

    // Cooking Q : 1100 - 1999[F,B]
    if (_cookId == 'D')
    {
        printf("[11:00 am] \tCook %c is Ready\n", _cookId);
        fflush(stdout);
    }
    else
    {
        printf("[11:00 am] Cook %c is Ready\n", _cookId);
        fflush(stdout);
    }
    int alreadyLeft = -1;

    while (true)
    {

        // Wait on cook
        P(cook);

        // Wait on mutex
        P(mutex);

        int front = M[1100]; // Front of the cook-Queue
        int back = M[1101];  // Back of the cook-Queue
        int _time = M[0];    // Current-time

        // Read the Cooking Queue
        int waiter_no, cust_id, no_of_Person;
        if (front <= back)
        {
            waiter_no = M[front];
            cust_id = M[front + 1];
            no_of_Person = M[front + 2];
            M[3] -= 1;

            // Update the front of the queue(Dequeu)
            M[1100] = M[1100] + 3;

            // Print the Message
            if (_cookId == 'D')
            {
                printf("[%02d:%02d %cm] \tCook %c : Preparing order (Waiter %c , Customer %d , Count %d)\n", getHour(_time), getMin(_time), getMer(_time), _cookId, 'U' + waiter_no, cust_id, no_of_Person);
                fflush(stdout);
            }
            else
            {
                printf("[%02d:%02d %cm] Cook %c : Preparing order (Waiter %c , Customer %d , Count %d)\n", getHour(_time), getMin(_time), getMer(_time), _cookId, 'U' + waiter_no, cust_id, no_of_Person);
                fflush(stdout);
            }
            // Release the Mutex
            V(mutex);

            // Take time to perpare food
            int timeTaken = no_of_Person * 5; // Minutes

            usleep(timeTaken * 100000);

            // wait on Mutex to Update the time
            P(mutex);
            // See if you can update the time
            if (M[0] > _time + timeTaken)
            {
                printf("cook %c => Error : Setting time to a smaller value\n", _cookId);
                fflush(stdout);
                exit(1);
            }
            else
            {
                M[0] = _time + timeTaken;
                _time = M[0];
            }
            alreadyLeft = M[4];
            if (_cookId == 'D')
            {
                printf("[%02d:%02d %cm] \tCook %c : Prepared order (Waiter %c , Customer %d , Count %d)\n", getHour(_time), getMin(_time), getMer(_time), _cookId, 'U' + waiter_no, cust_id, no_of_Person);
                fflush(stdout);
            }
            else
            {
                printf("[%02d:%02d %cm] Cook %c : Prepared order (Waiter %c , Customer %d , Count %d)\n", getHour(_time), getMin(_time), getMer(_time), _cookId, 'U' + waiter_no, cust_id, no_of_Person);
                fflush(stdout);
            }
            // Signal the Corresponding Waiter
            M[100 + waiter_no * 200] = cust_id;

            // Release the mutex
            V(mutex);

            // Signal waiter
            V(waiter[waiter_no]);

            /*Sub-Routing for checking if it is time to Leave*/
            if (_time > 240 && alreadyLeft == 0)
            {
                /*Update the Already Left and Leave this Hell*/
                P(mutex);

                /*Incrment already_Left by 1*/
                M[4] += 1;

                /*Release Mutex*/
                V(mutex);

                /*Print Message*/
                if (_cookId == 'D')
                {
                    printf("[%02d:%02d %cm]\t Cook %c : Leaving\n", getHour(_time), getMin(_time), getMer(_time), _cookId);
                    fflush(stdout);
                }
                else
                {
                    printf("[%02d:%02d %cm] Cook %c : Leaving\n", getHour(_time), getMin(_time), getMer(_time), _cookId);
                    fflush(stdout);
                }
                exit(0);
            }
            else if (_time > 240 && alreadyLeft == 1)
            {
                /*Check if there are any Orders left to serve*/
                int flag = true;
                P(mutex);
                for (int i = 0; i < 5; i++)
                {
                    // Pending Orders
                    if (M[100 + i * 200 + 1] > 0)
                    {
                        flag = false;
                        break;
                    }
                }

                if (flag)
                {
                    // Signal all the Waiters and Leave
                    for (int i = 0; i < 5; i++)
                    {
                        if (M[100 + i * 200] != -1)
                        {
                            continue;
                        }
                        M[100 + i * 200] = 0;
                        V(waiter[i]);
                    }
                    V(mutex);
                }
                else
                {
                    V(mutex);
                    continue;
                }

                printf("[%02d:%02d %cm] Cook %c : Leaving\n", getHour(_time), getMin(_time), getMer(_time), _cookId);
                fflush(stdout);

                exit(0); // Leave
            }
            else
            {
                /*You are allowed to live more*/
            }
        }
        else
        {
            /*Hurray Time to Leave...*/
            if (_cookId == 'D')
            {
                printf("[%02d:%02d %cm]\t Cook %c : Leaving\n", getHour(_time), getMin(_time), getMer(_time), _cookId);
                fflush(stdout);
            }
            else
            {
                printf("[%02d:%02d %cm] Cook %c : Leaving\n", getHour(_time), getMin(_time), getMer(_time), _cookId);
                fflush(stdout);
            }
            exit(0);
        }
    }
}

// Driver code
int main()
{
    // pop and vop
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    // Creating Key
    key_t mutex_key = ftok("/", 'A');
    key_t cook_key = ftok("/", 'B');
    key_t waiter_key[5];
    for (int i = 0; i < 5; i++)
        waiter_key[i] = ftok("/", 'C' + i);

    // Get the Semaphores
    mutex = semget(mutex_key, 1, 0777 | IPC_CREAT);
    cook = semget(cook_key, 1, 0777 | IPC_CREAT);
    if (mutex == -1 || cook == -1)
    {
        perror("__semget failed");
        exit(1);
    }
    for (int i = 0; i < 5; i++)
    {
        waiter[i] = semget(waiter_key[i], 1, 0777 | IPC_CREAT);
        if (waiter[i] == -1)
        {
            perror("semget failed");
            exit(1);
        }
    }

    // semctl function call
    semctl(mutex, 0, SETVAL, 1);
    semctl(cook, 0, SETVAL, 0);
    for (int i = 0; i < 5; i++)
        semctl(waiter[i], 0, SETVAL, 0);

    // Creating the Semaphores for Customers
    key_t customerKey = ftok("/", 'K');
    customer = semget(customerKey, 200, 0777 | IPC_CREAT);

    if (customer == -1)
    {
        perror("semget failed");
        exit(1);
    }

    // semctl function
    for (int i = 0; i < 200; i++)
        semctl(customer, i, SETVAL, 0);

    // Creating Memory
    key_t shm_key = ftok("/", 'Z');
    int shmid = shmget(shm_key, SHM_SIZE * sizeof(int), 0666 | IPC_CREAT);

    if (shmid == -1)
    {
        perror("shmget failed");
        exit(1);
    }

    M = (int *)shmat(shmid, NULL, 0);
    if (M == (int *)-1)
    {
        perror("shmat failed");
        exit(1);
    }

    // Initialzing the Global vars in shared Mem
    M[0] = 0;  // current-time
    M[1] = 10; // number of empty tables
    M[2] = 0;  // waiter number to serve the next customer
    M[3] = 0;  // number of orders pending for the cooks
    M[4] = 0;  // Number of cook already left

    // Initializing the front and the Back of the cook-Queue[1100-1999]
    M[1100] = 1102; // i
    M[1101] = 1099; // i-3

    // Initializing all the Waiter Queue
    for (int i = 0; i < 5; i++)
    {
        int _regIdx = 100 + i * 200;
        M[_regIdx] = -1;              // FR
        M[_regIdx + 1] = 0;           // PO(No Initially Waiting)
        M[_regIdx + 2] = _regIdx + 4; // Front(i)
        M[_regIdx + 3] = _regIdx + 2; // Back(i-2)
    }

    // create Cooks C and D
    if (fork() == 0)
    {
        /*child Process : cook C*/
        cmain('C');
    }
    if (fork() == 0)
    {
        /*child Process : cook D*/
        cmain('D');
    }

    for (int i = 0; i < 2; i++)
        wait(NULL);
}