#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 2000
#define true 1
#define false 0

// Semaphore Operations
#define P(s) semop(s, &pop, 1)
#define V(s) semop(s, &vop, 1)

// Declaring semaphores and shared memory
// Shared  Semaphores
int mutex, cook;
int waiter[5];
int customer;

// Shared Memory
int *M;

// pop and vop
struct sembuf pop, vop;

// Get hour
int getHour(int min)
{
    switch (min / 60)
    {
    case 0:
        return 11;
    case 1:
        return 12;
    case 2:
        return 1;
    case 3:
        return 2;
    case 4:
        return 3;
    }
    return -1; // Never Executed
}

// GetMinute
int getMin(int min)
{
    return min % 60;
}

// Get Meridian
char getMer(int min)
{
    if (min >= 60)
        return 'p';
    else
        return 'a';
}

// customer code
int cmain(int _custId, int arrivalTime, int count)
{
    /*Beautiful Arrival Message*/
    printf("[%02d:%02d %cm] Customer %d arrives (count = %d)\n", getHour(arrivalTime), getMin(arrivalTime), getMer(arrivalTime), _custId, count);
    fflush(stdout);

    // check time
    P(mutex);
    M[0] = arrivalTime;
    if (arrivalTime > 240)
    {
        printf("[%02d:%02d %cm]\t\t\t\t Customer %d leaves (count = %d)\n", getHour(arrivalTime), getMin(arrivalTime), getMer(arrivalTime), _custId, count);
        fflush(stdout);
        V(mutex);
        exit(0);
    }

    // Wait on Mutex to check the Number of free table
    if (M[1] <= 0)
    {
        printf("[%02d:%02d %cm]\t\t\t\t Customer %d leaves (count = %d)\n", getHour(arrivalTime), getMin(arrivalTime), getMer(arrivalTime), _custId, count);
        fflush(stdout);
        V(mutex);
        exit(0);
    }

    // Occupy the Free Table
    M[1] -= 1;

    // Read the Customer Who is gonna serve
    int servedBy = M[2];

    // Write to the Queue of the Corresponding Waiter
    int _regIdx = 100 + servedBy * 200;

    // Increment his PO
    M[_regIdx + 1]++;

    // Increment back(Enqeue)
    M[_regIdx + 3] += 2;
    int back = M[_regIdx + 3];
    M[back + 0] = _custId;
    M[back + 1] = count;

    // Increment the Waiter
    M[2] = (M[2] + 1) % 5;

    // Signal the corresponding waiter
    V(waiter[servedBy]);

    // signal mutex
    V(mutex);

    // Wait on customer
    pop.sem_num = _custId - 1;
    vop.sem_num = _custId - 1;

    P(customer);

    // Reset the pop and vop
    pop.sem_num = vop.sem_num = 0;
    P(mutex);

    // Decide the orderTime
    int ordertime = M[0];

    V(mutex);

    usleep(100000);
    printf("[%02d:%02d %cm] \tCustomer %d : Order Placed to waiter %c\n", getHour(ordertime + 1), getMin(ordertime + 1), getMer(ordertime + 1), _custId, 'U' + servedBy);
    fflush(stdout);

    // Again wait untill food is ready
    pop.sem_num = _custId - 1;
    vop.sem_num = _custId - 1;
    P(customer);

    // Reset pop,vop
    pop.sem_num = vop.sem_num = 0;

    // wait on mutex
    P(mutex);
    int recvtime = M[0];
    printf("[%02d:%02d %cm] \t\tCustomer %d : gets food [waiting time = %d]\n", getHour(recvtime), getMin(recvtime), getMer(recvtime), _custId, recvtime - arrivalTime);
    fflush(stdout);

    // Release mutex
    V(mutex);

    // Eat for 30 Mins and Updates the time...
    usleep(3000000); // Eat

    /*Finish time*/
    int finishTime = recvtime + 30;

    // wait on mutex
    P(mutex);
    M[0] = finishTime;
    printf("[%02d:%02d %cm]\t\t\t\t Customer %d leaves (count = %d)\n", getHour(finishTime), getMin(finishTime), getMer(finishTime), _custId, count);
    fflush(stdout);

    // Leave the Table
    M[1] += 1;

    // Release mutex
    V(mutex);

    // Simply Exit
    exit(0);
}

// Driver code
int main()
{
    // pop and vop
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    // Get the Key
    key_t mutex_key = ftok("/", 'A');
    key_t cook_key = ftok("/", 'B');
    key_t waiter_key[5];
    for (int i = 0; i < 5; i++)
        waiter_key[i] = ftok("/", 'C' + i);

    // Get the Semaphores
    mutex = semget(mutex_key, 1, 0777);
    cook = semget(cook_key, 1, 0777);
    if (mutex == -1 || cook == -1)
    {
        perror("semget failed");
        exit(1);
    }
    for (int i = 0; i < 5; i++)
    {
        waiter[i] = semget(waiter_key[i], 1, 0777);
        if (waiter[i] == -1)
        {
            perror("semget failed");
            exit(1);
        }
    }

    // Creating the Semaphores for Customers
    key_t customerKey = ftok("/", 'K');
    customer = semget(customerKey, 200, 0777);

    if (customer == -1)
    {
        perror("semget failed");
        exit(1);
    }

    // Creating Memory
    key_t shm_key = ftok("/", 'Z');
    int shmid = shmget(shm_key, SHM_SIZE, 0666);

    if (shmid == -1)
    {
        perror("shmget failed");
        exit(1);
    }

    M = (int *)shmat(shmid, NULL, 0);
    if (M == (int *)-1)
    {
        perror("shmat failed");
        exit(1);
    }

    // Read the Customers.txt
    FILE *fptr = fopen("customers.txt", "r");
    if (fptr == NULL)
    {
        perror("Error Opening File");
        exit(1);
    }

    int _custId, arrivalTime, count;

    // Number of Customers
    int numOfCust = 0;

    // Read from the file
    int _time = 0;
    while (1)
    {
        fscanf(fptr, "%d", &_custId);
        if (_custId == -1)
        {
            break;
        }
        numOfCust++;

        fscanf(fptr, "%d", &arrivalTime);
        fscanf(fptr, "%d", &count);

        if (arrivalTime > _time)
        {
            usleep((arrivalTime - _time) * 100000);
        }
        _time = arrivalTime;

        if (fork() == 0)
        {
            /*Child Process : Customer*/
            cmain(_custId, arrivalTime, count);
        }
    }

    // Wait for all the Customer Processes to exit
    for (int i = 0; i < numOfCust; i++)
        wait(NULL);

    // Remove all the IPC shared Mem and Resources

    // Remove mutex
    if (semctl(mutex, 0, IPC_RMID, 0) == -1)
    {
        perror("Failed to remove mutex");
        exit(1);
    }
    // Remove cook
    if (semctl(cook, 0, IPC_RMID, 0) == -1)
    {
        perror("Failed to remove cook");
        exit(1);
    }

    for (int i = 0; i < 5; i++)
    {
        // Remove waiter
        if (semctl(waiter[i], 0, IPC_RMID, 0) == -1)
        {
            perror("Failed to remove waiter");
            exit(1);
        }
    }

    // Remove the Customer
    if (semctl(customer, 0, IPC_RMID, 0) == -1)
    {
        perror("Failed to remove customer");
        exit(1);
    }

    return 0;
}