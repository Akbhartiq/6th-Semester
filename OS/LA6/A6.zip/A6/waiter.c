#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 2000
#define true 1
#define false 0

// Semaphore Operations
#define P(s) semop(s, &pop, 1)
#define V(s) semop(s, &vop, 1)

// Declaring semaphores and shared memory
// Shared  Semaphores
int mutex, cook;
int waiter[5];
int customer;

// Shared Memory
int *M;

// pop and vop
struct sembuf pop, vop;

// Get hour
int getHour(int min)
{
    switch (min / 60)
    {
    case 0:
        return 11;
    case 1:
        return 12;
    case 2:
        return 1;
    case 3:
        return 2;
    case 4:
        return 3;
    }
    return -1; // Never Executed
}

// GetMinute
int getMin(int min)
{
    return min % 60;
}

// Get Meridian
char getMer(int min)
{
    if (min >= 60)
        return 'p';
    else
        return 'a';
}

void printSpace(int _waiterNo)
{
    for (int i = 0; i < _waiterNo; i++)
        printf("\t");
}

// waiter code
int wmain(char _waiterId)
{
    /*Get the waiter-Number*/
    int _waiterNo = _waiterId - 'U';

    // Print the arrival Message
    printf("[11:00 am] ");
    printSpace(_waiterNo);
    printf("Waiter %c is ready\n", _waiterId);
    fflush(stdout);

    // Idea of the Queue[FR|PO|F|B|Queue]
    int _regIdx = 100 + _waiterNo * 200;

    // Enter the Inf loop
    while (true)
    {
        // wait on waiter[_waiterNo]
        P(waiter[_waiterNo]);

        // wait on Mutex
        P(mutex);

        // check if cook has given you the signal
        if (M[_regIdx] != -1)
        {
            /*M[_regIdx] customer food is prepared*/
            int currTime = M[0];

            /*For some Cusomter Food has been Prepared*/
            if (M[_regIdx])
            {
                /*Set the pop,vop*/
                pop.sem_num = vop.sem_num = M[_regIdx] - 1;
                printf("[%02d:%02d %cm] ", getHour(currTime), getMin(currTime), getMer(currTime));
                printSpace(_waiterNo);
                printf("Waiter %c : Serving food to Customer %d\n", _waiterId, M[_regIdx]);
                fflush(stdout);
                V(customer);
            }

            // Check if time is >= 240 Min and this is your last Customers
            if (currTime > 240 && (M[_regIdx + 1] == 0 || M[_regIdx] == 0))
            {
                /*Completed your Job*/
                // Reset the pop,vop
                M[_regIdx] = -1;
                pop.sem_num = vop.sem_num = 0;
                V(mutex);

                // print Leaving Message
                printf("[%02d:%02d %cm] ", getHour(currTime), getMin(currTime), getMer(currTime));
                printSpace(_waiterNo);
                printf("Waiter %c : Leaving\n", _waiterId);
                fflush(stdout);

                exit(0);
            }

            // Reset the M[_regIdx]
            M[_regIdx] = -1;

            // Reset the pop,vop
            pop.sem_num = vop.sem_num = 0;
            V(mutex);
        }
        else if (M[_regIdx + 1] > 0)
        {
            /*Take order from the Customer*/
            int front = M[_regIdx + 2];
            int currTime = M[0];

            // Get
            int custId = M[front];
            int count = M[front + 1];

            // Deque
            M[_regIdx + 2] = M[_regIdx + 2] + 2;

            // Decrement the PO
            M[_regIdx + 1]--;

            // Signal the Customer
            pop.sem_num = vop.sem_num = custId - 1;
            V(customer);

            // Reset the pop,vop
            pop.sem_num = vop.sem_num = 0;

            V(mutex);

            // Take order [1 Min]
            usleep(100000);

            P(mutex);

            // See if you can update the time
            if (M[0] > currTime + 1)
            {
                printf("waiter%c : setting time to a smaller value\n", _waiterId);
                fflush(stdout);
                exit(1);
            }
            else
            {
                M[0] = currTime + 1;
            }

            printf("[%02d:%02d %cm] ", getHour(currTime + 1), getMin(currTime + 1), getMer(currTime + 1));
            printSpace(_waiterNo);
            printf("Waiter %c : Placing Order for Customer %d\n", _waiterId, custId);
            fflush(stdout);

            // Calculate the new back position first
            int new_back = M[1101] + 3;
            // Update back pointer
            M[1101] = new_back;
            // Write order details
            M[new_back] = _waiterNo;
            M[new_back + 1] = custId;
            M[new_back + 2] = count;
            M[3] += 1;

            // Signal the Cook
            V(cook);

            // Signal the Mutex
            V(mutex);
        }
        else
        {
            /*M[_regIdx] is -1*/
            int currTime = M[0];
            if (currTime > 240)
            {
                printf("[%02d:%02d %cm] ", getHour(currTime), getMin(currTime), getMer(currTime));
                printSpace(_waiterNo);
                printf("Waiter %c : Leaving\n", _waiterId);
                fflush(stdout);

                /*Release the Mutex*/
                V(mutex);
                exit(0);
            }
            V(mutex);
        }
    }
}

// Driver code
int main()
{
    // pop and vop
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1;
    vop.sem_op = 1;

    // Get the Key
    key_t mutex_key = ftok("/", 'A');
    key_t cook_key = ftok("/", 'B');
    key_t waiter_key[5];
    for (int i = 0; i < 5; i++)
        waiter_key[i] = ftok("/", 'C' + i);

    // Get the Semaphores
    mutex = semget(mutex_key, 1, 0777);
    cook = semget(cook_key, 1, 0777);
    if (mutex == -1 || cook == -1)
    {
        perror("semget failed");
        exit(1);
    }
    for (int i = 0; i < 5; i++)
    {
        waiter[i] = semget(waiter_key[i], 1, 0777);
        if (waiter[i] == -1)
        {
            perror("semget failed");
            exit(1);
        }
    }

    // Creating the Semaphores for Customers
    key_t customerKey = ftok("/", 'K');
    customer = semget(customerKey, 200, 0777);

    if (customer == -1)
    {
        perror("semget failed");
        exit(1);
    }

    // Get Shared Memory
    key_t shm_key = ftok("/", 'Z');
    int shmid = shmget(shm_key, SHM_SIZE * sizeof(int), 0666);

    if (shmid == -1)
    {
        perror("shmget failed");
        exit(1);
    }

    M = (int *)shmat(shmid, NULL, 0);
    if (M == (int *)-1)
    {
        perror("shmat failed");
        exit(1);
    }

    // Create the 5 childs
    for (int i = 0; i < 5; i++)
    {
        if (fork() == 0)
        {
            wmain('U' + i);
        }
    }

    // wait for all the child exits
    for (int i = 0; i < 5; i++)
        wait(NULL);

    return 0;
}